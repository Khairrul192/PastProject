<?php

include 'header.php';
?>
<body>
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
          </div>
        </div>
    </section>
    <!--main content end-->
<center><h2>Welcome</h2></center>
    </section>

        <?php
include 'footer.php';
?>