<?php
require_once '../../library/database.php';

class supplierModel{
    public $SuppComp,$email,$CNo,$AccNo,$SRegNo,$SuppDetail, $suppid;
    
    function addsupplier(){
        $sql = "insert into supplier(RegNo,SuppEmail,SuppCNo,SuppCompany,SuppDetail,SuppAccno) values(:SRegNo, :email, :CNo, :SuppComp, :SuppDetail, :AccNo)";
        $args = [':SRegNo'=>$this->SRegNo, ':email'=>$this->email, ':CNo'=>$this->CNo, ':SuppComp'=>$this->SuppComp, ':SuppDetail'=>$this->SuppDetail, ':AccNo'=>$this->AccNo];
        $stmt = DB::run($sql, $args);
        $count = $stmt->rowCount();
        return $count;
    }
    
    function viewallsupplier(){
        $sql = "select * from supplier";
        return DB::run($sql);
    }
    
    function viewsupplier(){
        $sql = "select * from supplier where RegNo=:viewsupp";
        $args = [':viewsupp'=>$this->SRegNo];
        return DB::run($sql,$args);
    }
    
    function modifysupplier(){
        $sql = "update supplier set SuppEmail=:email,SuppCNo=:CNo,SuppCompany=:SuppComp,SuppDetail=:SuppDetail,SuppAccno=:AccNo where RegNo=:SRegNo";
        $args = [':SRegNo'=>$this->SRegNo, ':email'=>$this->email, ':CNo'=>$this->CNo, ':SuppComp'=>$this->SuppComp, ':SuppDetail'=>$this->SuppDetail, ':AccNo'=>$this->AccNo];
        return DB::run($sql,$args);
    }
  
    function deletesupplier(){
        $sql = "delete from supplier where RegNo=:delsupp";
        $args = [':delsupp'=>$this->SRegNo];
        return DB::run($sql,$args);
    }
}