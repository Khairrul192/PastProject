<?php
require_once 'header.php';
require_once '../../controller/clerk/prodController.php';

$product = new ProdController();
$show = $product ->viewallproducts();

if(isset($_POST['delete'])){
    $product->delete();
}

?>

    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-bars"></i>Products</li>
            </ol>
          </div>
        </div>
             <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Product
              </header>

              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                      <th><i class="icon_cart_alt"></i> Category</th>
                      <th><i class="icon_cart"></i> Sub Category</th>  
                      <th><i class="fa fa-barcode"></i> Code</th>
                      <th><i class="fa fa-bars"></i> Name</th>
                      <th><i class="fa fa-tag"></i> Retail Price</th>
                      <th><i class="fa fa-truck"></i> Supplier</th>
                      <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>
                <?php
                    foreach($show as $row){
                       echo "<tr>"
                        . "<td>".$row['categoryName']."</td>"
                        . "<td>".$row['SubCategoryName']."</td>"
                        . "<td>".$row['ProdCode']."</td>"
                        . "<td>".$row['ProdName']."</td>"
                        . "<td>".$row['ProdPrice']."</td>"
                        . "<td>".$row['SuppCompany']."</td>";
                       ?>
                <td><form action="" method="POST">
                            <input type="hidden" name="delprod" value="<?=$row['ProdId']?>"> <input type="submit" class="btn btn-danger" name="delete" value="Delete Product">&nbsp;
                        </form></td>
                      <?php 
                      echo "</tr>";
                }
                    ?>
              </table>
              
            </section>
          </div>
        </div>
          <div><a class="btn btn-success" href="addprod.php">New Product</a></div></div>
      </section>
    <!--main content end-->
  </section>
<?php
include 'footer.php';
?>
