<?php
require_once 'header.php';
require_once '../../controller/clerk/categoryController.php';

$category = new categoryController();
$cat = $category->category();
$rack = $category->viewracks();

if(isset($_POST['addrack'])){// add prodrack
   $category->addprodrack();
}

$data = $category->viewprodrack(); // view warehouse rack detail
$dataa = $category->viewprodrack2(); // view display rack detail

if(isset($_POST['delete'])){
    $category->delwarehouse();
}

if(isset($_POST['delete2'])){
    $category->deldisp();
}
?>

    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-laptop"></i>Manage Product Rack</li>
            </ol>
          </div>
        </div>
        <div class="row">
            <div class="col-lg-7">
                <br>
              <form class="form" method="POST" action="">
                    <div class="form-group ">
                      <label class="control-label col-lg-3">Category</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="category" name="category" required>
                                <option disabled selected value>Select Category</option>
                                <?php
                                foreach($cat as $view){
                                    echo "<option value='".$view['categoryID']."'>".$view['categoryName']."</option>";
                                }
                                ?>
                            </select>
                      </div><br><br>
                      <label class="control-label col-lg-3">Sub Category</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="subcategory" name="subcategory" required>
                                <option disabled selected value>Select Sub Category</option>
                            </select>
                      </div><br><br>
                      
                      <label class="control-label col-lg-3">Product</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="product" name="product" required>
                                <option disabled selected value>Select Product</option>
                            </select>
                      </div><br><br>
                      
                      <label class="control-label col-lg-3">Location</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="placement" name="type" required>
                                <option disabled selected value>Select Location</option>
                                <?php
                                foreach($rack as $view){
                                    echo "<option value='".$view['type']."'>".$view['type']."</option>";
                                }
                                ?>
                            </select>
                      </div><br><br>
                      
                      <label class="control-label col-lg-3">Rack No</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="rack" name="rack" required>
                                <option disabled selected value>Select Rack</option>
                            </select>
                      </div>    
                      <input class="btn btn-info" type="submit" name="addrack" value="Add Product">
                    </div>
                </form>
            </div>
          </div>
        <div class="row">
           <div class="col-lg-6"><!--warehouse rack-->
              <br>
            <section class="panel">
              <header class="panel-heading">
                Warehouse Rack
              </header>
                
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th><i class=""></i>Rack No</th> 
                    <th><i class="icon_cart_alt"></i> Category</th>
                    <th><i class="icon_cart"></i> Sub - Category</th>
                    <th><i class="icon_cart"></i> Product Name</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>
                <?php
                foreach($data as $row){
                       echo "<tr>"
                        . "<td>".$row['rackno']."</td>"
                        . "<td>".$row['categoryName']."</td>"
                        . "<td>".$row['SubCategoryName']."</td>"     
                        . "<td>".$row['ProdName']."</td>"
                       ?>
                <td><form action="" method="POST">
                            <input type="hidden" name="delware" value="<?=$row['warehouseId']?>"> <input type="submit" class="btn btn-danger" name="delete" value="Delete">&nbsp;
                        </form></td>
                      <?php 
                      echo "</tr>";
                }
                    ?>
              </table>
            </section>
          </div>
            <div class="col-lg-6"><!--Display rack-->
              <br>
            <section class="panel">
              <header class="panel-heading">
                Display Rack
              </header>
                
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th><i class=""></i>Rack No</th> 
                    <th><i class="icon_cart_alt"></i> Category</th>
                    <th><i class="icon_cart"></i> Sub - Category</th>
                    <th><i class="icon_cart"></i> Product Name</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>
                 <?php
                foreach($dataa as $row){
                       echo "<tr>"
                        . "<td>".$row['rackno']."</td>"
                        . "<td>".$row['categoryName']."</td>"
                        . "<td>".$row['SubCategoryName']."</td>"     
                        . "<td>".$row['ProdName']."</td>"
                       ?>
                <td><form action="" method="POST">
                            <input type="hidden" name="deldisp" value="<?=$row['DispId']?>"> <input type="submit" class="btn btn-danger" name="delete2" value="Delete">&nbsp;
                        </form></td>
                      <?php 
                      echo "</tr>";
                }
                    ?>
              </table>
              
            </section>
          </div>
        </div>
          
      </section>
    <!--main content end-->
  </section>
<script language="JavaScript" type="text/javascript" src="jquery-1.11.1.min.js"></script>
        <script>
function select_cir(id) {
$.ajax({
                type : "POST",
                data : {id:id},
                url : "process.php",
                success : function (res2) {
                        //alert(res2);
                        $('#subcategory').append(res2);
                },
                //error:function (res2){
                        //alert("error");}
        });
}

function select_cir2(idsub) {
    $.ajax({
                    type : "POST",
                    data : {idsub:idsub},
                    url : "process2.php",
                    success : function (res3) {
                            //alert(res2);
                            $('#product').append(res3);
                    },
                    //error:function (res3){
                            //alert("error");}
            });
}

function select_cir3(idsubs,subs) {
    $.ajax({
                    type : "POST",
                    data : {idsubs:idsubs,subs:subs},
                    url : "process3.php",
                    success : function (res4) {
                            //alert(res2);
                            $('#rack').append(res4);
                    },
                    //error:function (res4){
                            //alert("error");}
            });
}

$(document).ready(function(e) {
    
$("#category").on("change",function() {//cat n subcat
var id = document.getElementById("category").value;
document.getElementById("subcategory").options.length=0;
select_cir(id);
});

$("#subcategory").on("change",function() {//subcat and prod
    var idsub = document.getElementById("subcategory").value;
    document.getElementById("product").options.length=0;
    select_cir2(idsub);
});

$("#placement").on("change",function() {//placement and rack
    var idsubs = document.getElementById("placement").value;
      var subs = document.getElementById("subcategory").value;
    document.getElementById("rack").options.length=0;
    select_cir3(idsubs,subs);
});

});
</script>
<?php
include 'footer.php';
?>
