<?php
require_once 'header.php';
require_once '../../controller/clerk/supplierController.php';

$viewSupp = $_GET['viewsupplier'];

$supplier = new supplierController();
$data = $supplier->viewsupp($viewSupp); 
?>

<html>
    <body>
    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                <li><i class="fa fa-laptop"></i><a href="supplier.php">Supplier</a></li>
              <li><i class="fa fa-laptop"></i>Supplier Information</li>
            </ol>
          </div>
        </div>
    
    <!--supplier form start-->
                   <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Supplier Detail
              </header>
                <?php
            foreach($data as $detail){
            ?> 
              <div class="panel-body">
                <div class="form">
                  <form class="form-validate form-horizontal" method="POST" action="">
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Supplier Company</label>
                      <div class="col-lg-10">
                        <td><?=$detail['SuppCompany']?></td>
                      </div>
                    </div>
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Registration Number</label>
                      <div class="col-lg-10">
                        <td><?=$detail['RegNo']?></td>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Email</label>
                      <div class="col-lg-10">
                          <td><?=$detail['SuppEmail']?></td>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Contact Number</label>
                      <div class="col-lg-10">
                        <td><?=$detail['SuppCNo']?></td>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Account</label>
                      <div class="col-lg-10">
                        <td><?=$detail['SuppAccno']?></td>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Detail</label>
                      <div class="col-lg-10">
                        <td><?=$detail['SuppDetail']?></td>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                        <input type="button" class="btn btn-primary" 
                               onclick="location.href='editsupp.php?editsupplier=<?=$detail['RegNo']?>'" value="Update">&nbsp;
                        <input type="button" class="btn btn-default" onclick="location.href='supplier.php'" value="BACK">
                        
                      </div>
                    </div>
                </div>
<?php } ?>
              </div>
            </section>
          </div>
        </div>
           <!--supplier form end-->
            </section>

    <!--main content end-->
  </section>
</body>
</html>
<?php
include 'footer.php';
?>