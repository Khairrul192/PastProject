<?php
include 'header.php';
require_once '../../controller/supervisor/productController.php';

$product = new productController();
$data = $product->viewallprod();


?>
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-table"></i>Products</li>
            </ol>
          </div>
        </div>
        <!-- order table start-->
<!--        <button class="btn btn-info" onclick="goBack()">Product Code</button>
        <button class="btn btn-info" onclick="goBack()">Product Name</button>
        <button class="btn btn-info" onclick="goBack()">Retail Price</button>
        <button class="btn btn-info" onclick="goBack()">Category</button>
        <button class="btn btn-info" onclick="goBack()">Quantity</button>
        <button class="btn btn-info" onclick="goBack()">Vendor</button>
        <br><br>-->
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Product List
              </header>
              <div class="table-responsive">
                <table class="table">
                  <thead>
                      <th>No</th>
                      <th>Product Code</th>
                      <th>Product Name</th>
                      <th>Retail Price</th>
                      <th>Category</th>                      
                      <th>Quantity</th>
                      <th>Vendor</th>
                  </thead>
                      <?php
                    $counter=1;
                    foreach($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"
                        . "<td>".$row['ProdCode']."</td>"
                        . "<td>".$row['ProdName']."</td>"
                        . "<td>".$row['ProdPrice']."</td>"
                        . "<td>".$row['categoryName']."</td>"
                        . "<td>".((int)$row['Wqty']+(int)$row['Dqty'])."</td>"
                        . "<td>".$row['SuppCompany']."</td>"
                        ?>
                  <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
                </table>
                  
              </div>

            </section>
              <form>
              <input type="button" class="btn btn-default" onclick="location.href='index.php'" value="Back"> 
              </form>
          </div>
        </div>
        <!-- order table end-->
      </section>
    </section>          

<?php
include 'footer.php';
?>