<?php
include 'header.php';
require_once '../../controller/supervisor/orderController.php';

$Sorder = new SorderController();
$data = $Sorder->invoicelist();

?>

    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-table"></i>Invoice</li>
            </ol>
          </div>
        </div>
             <div class="row">
          <div class="col-sm-10">
            <section class="panel">
              <header class="panel-heading">
                Order History
              </header>

              <table class="table">
                <thead>
                  <tr>
                    <th><i class=""></i>No</th>
                    <th><i class="icon_document"></i>Invoice</th>  
                    <th><i class="icon_document_alt"></i>Store Receipt</th>
                    <th><i class="icon_calendar"></i> Date</th>
                    <th><i class="fa fa-truck"></i>Vendor</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>
                <?php
                    $counter=1;
                    foreach($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"
                        . "<td>".$row['RefNo']."</td>"
                        . "<td>".$row['receipt']."</td>"
                        . "<td>".$row['SuppCompany']."</td>"
                        . "<td>".$row['Date']."</td>"
                        ?> 
                <td>
                <form action="" method="POST">
                    <input type="button" class="btn btn-primary" value="View Invoice" onclick="location.href='viewinvoice.php?invoice=<?=$row['RefNo']?>'">&nbsp;
                </form>
                </td>
                <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
              </table>
              
            </section>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>   

<?php
include 'footer.php';
?>