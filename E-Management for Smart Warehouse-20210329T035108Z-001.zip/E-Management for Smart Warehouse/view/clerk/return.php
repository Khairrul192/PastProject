<?php
include 'header.php';
require_once '../../controller/supervisor/productController.php';

$product = new productController();
$data = $product ->viewreturnlist();

?>

    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-table"></i>Return History</li>
            </ol>
          </div>
        </div>
             <div class="row">
          <div class="col-sm-6">
            <section class="panel">
              <header class="panel-heading">
                Return History List
              </header>

              <table class="table">
                <thead>
                  <tr>
                    <th><i class=""></i>No</th>
                        <th><i class="icon_document"></i>Return</th>  
                    <th><i class="fa fa-truck"></i>Vendor</th>
                    <th><i class="fa fa-dashboard"></i>Date</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>
                <?php
                    $counter=1;
                    foreach($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"
                        . "<td>".$row['rerefer']."</td>"
                        . "<td>".$row['SuppCompany']."</td>"
                        . "<td>".$row['rerptdate']."</td>"
                        ?> 
                <td>
                <form action="" method="POST">
                    <input type="button" class="btn btn-primary" value="View Return" onclick="location.href='returnreport.php?viewreturn=<?=$row['rerefer']?>'">&nbsp;
                </form>
                </td>
                <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
              </table>
              
            </section>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>   

<?php
include 'footer.php';
?>