<?php
require_once '../../library/database.php';

class ProdModel{
    public $prodid,$prodcode,$prodname,$prodprice,$suppid, $cat, $regno, $rackno;
    
    
    function viewcategory(){
        $sql= "select * from category";
        return DB::run($sql);
    }
    
    function subcategory($categoryID){
        $sql = "select * from subcategory where categoryID=:categoryID";
        $args = [':categoryID'=> $categoryID];
        return DB::run($sql, $args);
    }
    
    function rackno($subcategoryID){
        $sql = "select * from rack where SubCategoryID=:SubCategoryID";
        $args = [':SubCategoryID'=> $subcategoryID];
        return DB::run($sql, $args);
    }
    
    function insertprod(){
        $sql = "insert into product (ProdCode, ProdName, ProdPrice,RegNo, categoryId, SubCategoryID) values(:prodcode,:prodname,:prodprice,:suppid,:cat,:subcat)";
        $args = [':prodcode'=>$this->prodcode, ':prodname'=>$this->prodname, ':prodprice'=>$this->prodprice, ':suppid'=> $this->supplier, ':cat'=>$this->category, ':subcat'=> $this->subcategory];
        $stmt = DB::run($sql, $args);
        $count = $stmt->rowCount();
        return $count;        
    }
    
    function viewallproducts(){
        $sql="select * from product,category,subcategory,supplier where product.categoryID=category.categoryID and product.SubCategoryID=subcategory.SubCategoryID and product.RegNo=supplier.RegNo order by categoryName asc";
        return DB::run($sql);
    }
    
    function viewprod(){
        $sql = "select * from product,category where product.categoryID = category.categoryID and ProdId=:viewprod";
        $args = [':viewprod'=>$this->prodid];
        return DB::run($sql,$args);
    }
    
    function modifyprod(){
        $sql="update product set ProdName=:prodname, ProdPrice=:prodprice, RackNo=:rackno where ProdId=:prodid";
        $args=[':prodid'=>$this->prodid,':prodname'=>$this->prodname,':prodprice'=>$this->prodprice,':rackno'=>$this->rackno];
        return DB::run($sql,$args);
    }
    
    function deleteproduct(){
        $sql = "delete from product where ProdId=:delprod";
        $args = [':delprod'=>$this->product];
        return DB::run($sql,$args);
    }
    
    function viewallprod() {
        $sql = "select * from warehouse,rack,product,category,subcategory where warehouse.RackId=rack.RackId and warehouse.ProdId=product.ProdId and product.categoryID=category.categoryID and product.SubcategoryID=subcategory.SubCategoryID order by rackno asc";
        return DB::run($sql);        
    }
    
    function vallprod() {
        $sql = "select * from display,rack,product,category,subcategory where display.RackId=rack.RackId and display.ProdId = product.ProdId and rack.categoryID=category.categoryID and rack.SubCategoryID=subcategory.SubCategoryID"; 
        return DB::run($sql);        
    }
    
//    function aod(){
//        $sql = "insert into display (rackNo, ProdId) values(:rackno,:prodname)";
//        $args = [':rackno'=>$this->rackno, ':prodname'=>$this->prodname];
//        $stmt = DB::run($sql, $args);
//        $count = $stmt->rowCount();
//        return $count;        
//    }
    
//    function viewAOD() {
//        $sql= "select * from display,product,category where display.ProdId = product.ProdId and product.categoryID=category.categoryID";
//        return DB::run($sql);
//    }
    
    function viewsupp(){
        $sql= "select * from supplier";
        return DB::run($sql);
    }

}
