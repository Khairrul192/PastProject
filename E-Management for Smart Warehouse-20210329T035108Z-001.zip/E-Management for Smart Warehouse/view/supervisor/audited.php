<?php
include 'header.php';
require_once '../../controller/supervisor/adjustmentController.php';

$product = new adjustmentController();
//warehouse start
$data = $product -> viewproduct();
if(isset($_POST['rackno'])){
    $SWI = $product->getwarehouseitem();
}
if(isset($_POST['addwaudit'])){
    $product->Waudit();
}
$VWI = $product->viewcountedW();
//warehouse end

//display start
$view = $product ->viewdisplay();
if(isset($_POST['norack'])){
    $SDI = $product->getdisplayitem();
}
if(isset($_POST['adddaudit'])){
    $product->Daudit();
}
$VDI = $product->viewcountedD();
//display end

//Overall 
$VAI = $product->viewoverall();
if(isset($_POST['savedd'])){
    $product->auditt();
}
?>


<section id="main-content">
  <section class="wrapper">

    <div class="row">
      <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
            <li><i class="icon_document"></i><a href="auditlist.php">Audit</a></li>
          <li><i class="icon_documents"></i>Create Audit</li>
        </ol>
      </div>
    </div>
      <section class="panel">
              <header class="panel-heading tab-bg-info ">
                <ul class="nav nav-tabs">
                  <li class="active">
                    <a data-toggle="tab" href="#Warehouse">Warehouse</a>
                  </li>
                  <li class="">
                    <a data-toggle="tab" href="#Display">Display</a>
                  </li>
                  <li class="">
                    <a data-toggle="tab" href="#CountedWarehouse">Counted Warehouse</a>
                  </li>
                  <li class="">
                    <a data-toggle="tab" href="#CountedDisplay">Counted Display</a>
                  </li>
                  <li class="">
                    <a data-toggle="tab" href="#Overall">Overall</a>
                  </li>
                </ul>
              </header>
          <div class="panel-body">
                <div class="tab-content">
                    <div id="Warehouse" class="tab-pane active">
                        <br>
                        
        <form  class="form-horizontal" action="" method="POST"> <!-- Warehouse start-->
         <div class="form-group">
            <label class="control-label col-lg-1">Rack No</label>
            <div class="col-sm-2">
                <select class="form-control" id="rackno" name="rackno" onchange="form.submit()">
                                <option disabled selected value>Select Rack</option>
                                <?php
                                foreach($data as $row){
                                    echo "<option value='".$row['RackId']."'>".$row['rackno']."</option>";
                                }
                                ?>
                </select>
            </div>            
          </div>
      </form><br>
      <div class="row">
          <div class="col-lg-8">
              <form  class="form-horizontal" action="" method="POST"> 
            <section class="panel">
              <header class="panel-heading">
                <i class="fa fa-bookmark"></i>Warehouse Auditing
              </header>
              <div class="panel-body">
                    
                  <!--table report-->
                  <table class="table table-striped table-advance table-hover">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Counted Quantity</th>
                <th>System Quantity</th>
              </tr> 
            </thead>
            <?php
            if(!empty($SWI)){
                foreach($SWI as $W){
                    echo "<tr>"?>
                <td><?php echo $W['ProdCode']?>
                        <input class="form-control" type="hidden" name="prodid[]" value="<?php echo $W['ProdId'] ?>"></td>
                <td><?php echo $W['ProdName']?></td>
                <td><input class="form-control col-sm-1" type="number" name="counted[]" value=""></td>
                <td><?php echo $W['Wqty']?></td>
            </tr>
            <?php
                echo "</tr>";}
                    }
                    ?>
          </table>
                    
              </div>

            </section>
              <p align="right"><input class="btn btn-info" align="right" type="submit" name="addwaudit" value="Save"></p>
              </form>
          </div>
     </div> <!--  Warehouse end-->
                    </div>
                    
                    <div id="Display" class="tab-pane"><br>
                  <form  class="form-horizontal" action="" method="POST"> <!-- Display start-->
         <div class="form-group">
            <label class="control-label col-lg-1">Rack No</label>
            <div class="col-sm-2">
                <select class="form-control" id="norack" name="norack" onchange="form.submit()">
                                <option disabled selected value>Select Rack</option>
                                <?php
                                foreach($view as $row){
                                    echo "<option value='".$row['RackId']."'>".$row['rackno']."</option>";
                                }
                                ?>
                </select>
            </div>            
          </div>
      </form><br>
      <div class="row">
          <div class="col-lg-8">
              <form  class="form-horizontal" action="" method="POST"> 
            <section class="panel">
              <header class="panel-heading">
                <i class="fa fa-bookmark"></i>Display Auditing
              </header>
              <div class="panel-body">

                  <!--table report-->
                  <table class="table table-striped table-advance table-hover">
            <thead>
              <tr>
                <th>Code</th>
                <th>Name</th>
                <th>Counted Qty</th>
                <th>System Qty</th>
              </tr> 
            </thead>
            <?php
            if(!empty($SDI)){
                foreach($SDI as $D){
                    echo "<tr>"?>
                <td><?php echo $D['ProdCode']?>
                    <input class="form-control" type="hidden" name="disp[]" value="<?php echo $D['DispId'] ?>">    
                    <input class="form-control" type="hidden" name="prod[]" value="<?php echo $D['ProdId'] ?>"></td>
                <td><?php echo $D['ProdName']?></td>
                <td><input class="form-control col-sm-1" type="number" name="count[]" value=""></td>
                <td><?php echo $D['Dqty']?></td>
            </tr>
            <?php
                echo "</tr>";}
                    }
                    ?>
          </table>
              </div>
            </section>
              <p align="right"><input class="btn btn-info" align="right" type="submit" name="adddaudit" value="Save"></p>
          </form>
          </div>
     </div> <!--  Display end-->
                  </div>
                    
        <div id="CountedWarehouse" class="tab-pane"><br>
        <div class="row"><!--counted display start-->
          <div class="col-lg-8">
            <section class="panel">
              <header class="panel-heading">
                <i class="fa fa-bookmark"></i>Counted Warehouse
              </header>
              <div class="panel-body">

                  <!--table report-->
                  <table class="table table-striped table-advance table-hover">
            <thead>
              <tr>
                <th>Rack No</th>
                <th>Code</th>
                <th>Name</th>
                <th>Counted Quantity</th>
                <th>System Quantity</th>
              </tr> 
            </thead>
            <?php
            if(!empty($VWI)){
                foreach($VWI as $WI){
                    echo "<tr>"?>
                <td><?php echo $WI['rackno']?></td>
                <td><?php echo $WI['ProdCode']?></td>
                <td><?php echo $WI['ProdName']?></td>
                <td><?php echo $WI['wareqty']?></td>
                <td><?php echo $WI['Wqty']?></td>
            </tr>
            <?php
                     echo "</tr>";
                       }}
                    ?>
          </table>
                    
              </div>

            </section>
          </div>
        </div><!--counted display end-->
                  </div>
                  <div id="CountedDisplay" class="tab-pane"><br>
        <div class="row"><!--counted display start-->
          <div class="col-lg-8">
            <section class="panel">
              <header class="panel-heading">
                <i class="fa fa-bookmark"></i>Counted Display
              </header>
              <div class="panel-body">

                  <!--table report-->
                  <table class="table table-striped table-advance table-hover">
            <thead>
              <tr>
                <th>Rack No</th>
                <th>Code</th>
                <th>Name</th>
                <th>Counted Qty</th>
                <th>System Qty</th>
              </tr> 
            </thead>
            <?php
            if(!empty($VDI)){
                foreach($VDI as $DI){
                    echo "<tr>"?>
                <td><?php echo $DI['rackno']?></td>
                <td><?php echo $DI['ProdCode']?></td>
                <td><?php echo $DI['ProdName']?></td>
                <td><?php echo $DI['disqty']?></td>
                <td><?php echo $DI['Dqty']?></td>
            </tr>
            <?php
                     echo "</tr>";
                       }}
                    ?>
          </table>
                    
              </div>

            </section>
          </div>
        </div><!--counted display end-->
                      
                  </div>
                  <div id="Overall" class="tab-pane"><br>
                  
        <div class="row"><!--Overall display start-->
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                  <i class="fa fa-bookmark"></i>Overall Audit 
              </header>
                <form action="" method="POST">
              <div class="panel-body">
                  <table class="table table-striped table-advance table-hover">
            <thead>
              <tr>
                <th>No</th>
                <th>Code</th>
                <th>Name</th>
                <th>Counted Warehouse</th>
                <th>Warehouse System Quantity</th>
                <th>Counted Display</th>
                <th>Display System Quantity</th>
                <th>Overall Count Quantity</th>
                <th>Overall System Quantity</th>
                <th>Difference</th>
                <th>Loss</th>
              </tr> 
            </thead>
            <?php
            if(!empty($VAI)){
                $counter=1;
                foreach($VAI as $AI){
//                    $a = $product ->vieww($AI['ProdCode']);
                    echo "<tr>";
                    if(((((int)$AI['wareqty']+(int)$AI['disqty'])-((int)$AI['Wqty']+(int)$AI['Dqty']))*((float)$AI['ProdPrice']) ) < 0){
                    ?>
                <td style="color:#FF0000"><?= $counter ?></td>
               
                <td style="color:#FF0000"><?= $AI['ProdCode']?>
                <input class="form-control" type="hidden" name="prodcode[]" value="<?php echo $AI['ProdCode'] ?>"></td>
                
                <td style="color:#FF0000"><?= $AI['ProdName']?>
                <input class="form-control" type="hidden" name="prodname[]" value="<?php echo $AI['ProdName'] ?>"></td>
                
                <td style="color:#FF0000"><?= $AI['wareqty']?>
                <input class="form-control" type="hidden" name="Wqty[]" value="<?php echo $AI['wareqty'] ?>"></td>
                
                <td style="color:#FF0000"><?= $AI['Wqty']?>
                <input class="form-control" type="hidden" name="Wsqty[]" value="<?php echo $AI['Wqty'] ?>"></td>
                
                <td style="color:#FF0000"><?= $AI['disqty']?>
                <input class="form-control" type="hidden" name="Dqty[]" value="<?php echo $AI['disqty'] ?>"></td>
                
                <td style="color:#FF0000"><?= $AI['Dqty']?>
                <input class="form-control" type="hidden" name="Dsqty[]" value="<?php echo $AI['Dqty'] ?>"></td>
                
                <td style="color:#FF0000"><?= (int)$AI['wareqty']+(int)$AI['disqty']?>
                <input class="form-control" type="hidden" name="Ocqty[]" value="<?= (int)$AI['wareqty']+(int)$AI['disqty']?>"></td>
                
                <td style="color:#FF0000"><?= (int)$AI['Wqty']+(int)$AI['Dqty']?>
                <input class="form-control" type="hidden" name="Osqty[]" value="<?= (int)$AI['Wqty']+(int)$AI['Dqty']?>"></td>
                
                <td style="color:#FF0000"><?= (((int)$AI['wareqty']+(int)$AI['disqty'])-((int)$AI['Wqty']+(int)$AI['Dqty']))?>
                <input class="form-control" type="hidden" name="differ[]" value="<?= (((int)$AI['wareqty']+(int)$AI['disqty'])-((int)$AI['Wqty']+(int)$AI['Dqty']))?>"></td>
                
                 <td style="color:#FF0000"><?=((((int)$AI['wareqty']+(int)$AI['disqty'])-((int)$AI['Wqty']+(int)$AI['Dqty']))*((float)$AI['ProdPrice']) )?>
                <input class="form-control" type="hidden" name="loss[]" value="<?=((((int)$AI['wareqty']+(int)$AI['disqty'])-((int)$AI['Wqty']+(int)$AI['Dqty']))*((float)$AI['ProdPrice']) )?>"></td>
            <?php
          }
          else{?>
           <td><?= $counter ?></td>
               
                <td><?= $AI['ProdCode']?>
                <input class="form-control" type="hidden" name="prodcode[]" value="<?php echo $AI['ProdCode'] ?>"></td>
                
                <td><?= $AI['ProdName']?>
                <input class="form-control" type="hidden" name="prodname[]" value="<?php echo $AI['ProdName'] ?>"></td>
                
                <td><?= $AI['wareqty']?>
                <input class="form-control" type="hidden" name="Wqty[]" value="<?php echo $AI['wareqty'] ?>"></td>
                
                <td><?= $AI['Wqty']?>
                <input class="form-control" type="hidden" name="Wsqty[]" value="<?php echo $AI['Wqty'] ?>"></td>
                
                <td><?= $AI['disqty']?>
                <input class="form-control" type="hidden" name="Dqty[]" value="<?php echo $AI['disqty'] ?>"></td>
                
                <td><?= $AI['Dqty']?>
                <input class="form-control" type="hidden" name="Dsqty[]" value="<?php echo $AI['Dqty'] ?>"></td>
                
                <td><?= (int)$AI['wareqty']+(int)$AI['disqty']?>
                <input class="form-control" type="hidden" name="Ocqty[]" value="<?= (int)$AI['wareqty']+(int)$AI['disqty']?>"></td>
                
                <td><?= (int)$AI['Wqty']+(int)$AI['Dqty']?>
                <input class="form-control" type="hidden" name="Osqty[]" value="<?= (int)$AI['Wqty']+(int)$AI['Dqty']?>"></td>
                
                <td><?= (((int)$AI['wareqty']+(int)$AI['disqty'])-((int)$AI['Wqty']+(int)$AI['Dqty']))?>
                <input class="form-control" type="hidden" name="differ[]" value="<?= (((int)$AI['wareqty']+(int)$AI['disqty'])-((int)$AI['Wqty']+(int)$AI['Dqty']))?>"></td>
                
                 <td><?=((((int)$AI['wareqty']+(int)$AI['disqty'])-((int)$AI['Wqty']+(int)$AI['Dqty']))*((float)$AI['ProdPrice']) )?>
                <input class="form-control" type="hidden" name="loss[]" value="<?=((((int)$AI['wareqty']+(int)$AI['disqty'])-((int)$AI['Wqty']+(int)$AI['Dqty']))*((float)$AI['ProdPrice']) )?>"></td>
          <?php
        }
                     echo "</tr>";
                     $counter++;
                       }}
                    ?>
          </table>
              </div> <br>
                  <table>
                      <tr>
                      <td align="center">      
                          <label class="control-label"> Audit Name </label>
                      </td>
                      <td>
                          <input class="form-control" name="auditname" type="text" required />
                      </td>
                      </tr>
                  </table><br>
               <input type="submit" class="btn btn-primary" name="savedd" value="Save">
               </form> 
            </section>
          </div>
        </div><!--Overall display end-->
                      
                  </div>
                </div>
              </div>
      </section>
  </section>
</section>                  
<script language="JavaScript" type="text/javascript" src="jquery-1.11.1.min.js"></script>
<script>
function select_cir(id) {
    $.ajax({
                    type : "POST",
                    data : {id:id},
                    url : "process.php",
                    success : function (res2) {
                            //alert(res2);
                            $('#rackno').append(res2);
                    },
                    error:function (res2){
                            alert("error");}
            });
}

$(document).ready(function(e) {
$("#itemcode").on("change",function() {
    var id = document.getElementById("itemcode").value;

    document.getElementById("rackno").options.length=0;

    select_cir(id);
});  
});


</script>
<?php
include 'footer.php';
?>

