<?php
require_once 'header.php';
require_once '../../controller/admin/userController.php';

$user = new userController();
$data = $user->viewC();

$user = new userController();
$dataa = $user->viewS();

if(isset($_POST['padam'])){
    $user->delsv();
}
if(isset($_POST['delete'])){
    $user->delcl();
}
?>

    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-laptop"></i>Staff</li>
            </ol>
          </div>
        </div>
             <div class="row">
          <div class="col-lg-8">
            <section class="panel">
              <header class="panel-heading">
                Supervisor
              </header>

              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                      <th><i class="icon_profile"></i> Name</th>
                      <th><i class="icon_mobile"></i> Phone No</th>                    
                    <th><i class="icon_mail"></i> Email</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>               
                    <?php
                    foreach ($dataa as $detail){
                        echo "<tr>"
                        ."<td>".$detail['SvName']."</td>"
                        ."<td>".$detail['SvPNo']."</td>"
                        ."<td>".$detail['SvEmail']."</td>";
                        
                       ?>
                <td><form action="" method="POST">
                    <input type="button" class="btn btn-success" onclick="location.href='viewsv.php?viewsupervisor=<?=$detail['SvId']?>'" value="View">&nbsp;
                    <input type="hidden" name="SvId" value="<?=$detail['SvId']?>"> <input type="submit" class="btn btn-danger" name="padam" value="Delete">
                    </form></td>
                    <?php
                     echo "</tr>";
                    }
                    ?>
              </table>
            </section>
              
              <section class="panel">
              <header class="panel-heading">
                Clerk
              </header>

              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                      <th><i class="icon_profile"></i> Name</th>
                      <th><i class="icon_mobile"></i> Phone No</th>                    
                    <th><i class="icon_mail"></i> Email</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>               
                    <?php
                    foreach ($data as $detail){
                        echo "<tr>"
                        ."<td>".$detail['ClerkName']."</td>"
                        ."<td>".$detail['ClerkPNo']."</td>"
                        ."<td>".$detail['ClerkEmail']."</td>";
                        
                       ?>
                <td><form action="" method="POST">
                    <input type="button" class="btn btn-success" onclick="location.href='viewcl.php?viewclerk=<?=$detail['ClerkId']?>'" value="View">&nbsp;
                    <input type="hidden" name="ClerkId" value="<?=$detail['ClerkId']?>"> <input type="submit" class="btn btn-danger" name="delete" value="Delete">
                    </form></td>
                    <?php
                     echo "</tr>";
                    }
                    ?>
              </table>
            </section>
              
          </div>
        </div>
          <div><a class="btn btn-success" href="register.php">New Registration</a></div></div>
      </section>
    <!--main content end-->
  </section>

<?php
include 'footer.php';
?>
