<?php
include 'header.php';
require_once '../../controller/admin/userController.php';

$user = new userController();

if(isset($_POST['add'])){
    $user->insert();
}
?>
<body>
    
    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                <li><i class="fa fa-laptop"></i><a href="User.php">Staff</a></li>
              <li><i class="fa fa-laptop"></i>User Registration</li>
            </ol>
          </div>
        </div>
    
    <!--user form start-->
         <div class="row">
          <div class="col-lg-8">
            <section class="panel">
              <header class="panel-heading">
                User Registration
              </header>
              <div class="panel-body">
                <div class="form">
                  <form class="form-validate form-horizontal" method="POST" action="">
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Username<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control" name="Id" type="text" required />
                      </div>
                    </div>
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Password<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control" name="password" type="text" required />
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Name<span class="required">*</span></label>
                      <div class="col-lg-10">
                          <input class="form-control" name="name" type="text" required />
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Email<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control" type="email" name="email" required></td>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Phone Number<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control" name="Pno" type="text" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))"required />
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Address<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control" id="subject" name="address" type="text" required />
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Type<span class="required">*</span></label>
                      <div class="col-lg-10">
                          <select class="form-control" name="role">
                            <option value="clerk">Clerk</option>
                            <option value="supervisor">Supervisor</option>
                        </select>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                          <input class="btn btn-success" type="submit" name="add" value="Register">
                        <button class="btn btn-default" onclick="goBack()">Cancel</button>
                        <script>
                        function goBack() {
                          window.history.back();
                        }
                        </script>
                      </div>
                    </div>
                  </form>
                </div>

              </div>
            </section>
          </div>
        </div>
           <!--supplier form end-->
            </section>
          </div>
        </div>
    <!--main content end-->
  </section>
</body>

</html>
<?php
include 'footer.php';
?>