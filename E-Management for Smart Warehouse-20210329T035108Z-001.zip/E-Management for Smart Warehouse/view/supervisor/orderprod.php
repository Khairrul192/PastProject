<?php
require 'header.php';
require_once '../../controller/supervisor/orderController.php';

$Sorder = new SorderController();
$cat = $Sorder->category();

$data = $Sorder->viewordersupplier();

if(isset($_POST['add'])){
    $Sorder->addorder();
}

if(isset($_POST['adds'])){
    $Sorder->setorder();
}

if(isset($_POST['delete'])){
    $Sorder->deleteorder();
}

?>
<section id="main-content">
  <section class="wrapper">

        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-laptop"></i>Order Product</li>
            </ol>
          </div>
        </div>
        <div class="row">
            <div class="col-lg-7">
                <br>
              <form class="form" method="POST" action="">
                    <div class="form-group ">
                      <label class="control-label col-lg-3">Category</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="category" name="category">
                                <option disabled selected value>Select Category</option>
                                <?php
                                foreach($cat as $view){
                                    echo "<option value='".$view['categoryID']."'>".$view['categoryName']."</option>";
                                }
                                ?>
                            </select>
                      </div><br><br>
                      <label class="control-label col-lg-3">Sub Category</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="subcategory" name="subcategory">
                                <option disabled selected value>Select Sub Category</option>
                            </select>
                      </div><br><br>
                      
                      <label class="control-label col-lg-3">Product</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="product" name="product">
                                <option disabled selected value>Select Product</option>
                            </select>
                      </div>
                      
                      <input class="btn btn-info" type="submit" name="add" value="Add Product">
                    </div>
                </form>
            </div>
          </div><br>
         <div class="row">
      <div class="col-sm-12">
          <form class="form" method="POST" action="">
        <section class="panel">
          <header class="panel-heading">
            Order List
          </header>
          <table class="table">
            <thead>
              <tr>
                <th>No</th>
                <th>Code</th>
                <th>Name</th>
                <th>Order</th>
                <th>Quantity</th>
                <th>Supplier</th>
                <th>Action</th>
              </tr>
            </thead>               
                 <?php
                    $counter=1;
                    foreach($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"?>
                        <td><?php echo $row['ProdCode']?>
                        <input class="form-control" type="hidden" name="prodid[]" value="<?php echo $row['ProdId'] ?>"></td>
                        <?= "<td>".$row['ProdName']."</td>"?>
                        <td>
                            <input class="form-control" class="col-lg-2" name="order[]" type="number" required/>
                        </td>
                        <?= "<td>".((int)$row['Wqty']+(int)$row['Dqty'])."</td>"?>
                        <td><?php echo $row['SuppCompany']?>
                        <input class="form-control" type="hidden" name="suppid[]" value="<?php echo $row['RegNo'] ?>"></td>
                        
                        <td><form action="" method="POST">
                            <input type="hidden" name="delet" value="<?=$row['cartid']?>"> <input type="submit" class="btn btn-danger" name="delete" value="Delete">&nbsp;
                        </form></td>
                  <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
          </table>
            
        </section>
          <input type="submit" class="btn btn-success" name="adds" value="Appoint Order" onclick="location.href='setorder.php'">&nbsp;
          </form>
          
      </div>
    </div>
  </section>
<!--main content end-->
<script language="JavaScript" type="text/javascript" src="jquery-1.11.1.min.js"></script>
        <script>
function select_cir(id) {
$.ajax({
                type : "POST",
                data : {id:id},
                url : "process2.php",
                success : function (res2) {
                        //alert(res2);
                        $('#subcategory').append(res2);
                },
                //error:function (res2){
                        //alert("error");}
        });
}

function select_cir2(idsub) {
    $.ajax({
                    type : "POST",
                    data : {idsub:idsub},
                    url : "process3.php",
                    success : function (res3) {
                            //alert(res2);
                            $('#product').append(res3);
                    },
                    //error:function (res3){
                            //alert("error");}
            });
}

$(document).ready(function(e) {
    
$("#category").on("change",function() {//cat n subcat
var id = document.getElementById("category").value;
document.getElementById("subcategory").options.length=0;
select_cir(id);
});

$("#subcategory").on("change",function() {//subcat and prod
    var idsub = document.getElementById("subcategory").value;
    document.getElementById("product").options.length=0;
    select_cir2(idsub);
});

});
</script>
</section>   

<?php
include 'footer.php';
?>