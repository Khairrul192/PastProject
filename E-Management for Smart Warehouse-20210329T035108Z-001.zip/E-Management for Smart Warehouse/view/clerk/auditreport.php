<?php
include 'header.php';
require_once '../../controller/supervisor/adjustmentController.php';

$product = new adjustmentController();
$data = $product->viewaudit();

?>

    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="icon_documents"></i>Audit</li>
            </ol>
          </div>
        </div>
          <div class="row">
              <div class="col-lg-6">
                <section class="panel">
                   <header class="panel-heading">
                    <i class="fa fa-bookmark"></i>Audit Report List
                  </header>
                  <div class="panel-body">
                      <!--table report-->
                      <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th><i class=""></i>No</th>
                    <th><i class="icon_document"></i>Name</th>  
                    <th><i class="fa fa-truck"></i>Date</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>               
                <?php
                    $counter=1;
                    foreach($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"
                        . "<td>".$row['auditname']."</td>"
                        . "<td>".$row['Date']."</td>"
                        ?> 
                <td>
                <form action="" method="POST">
                    <input type="button" class="btn btn-primary" value="View" onclick="location.href='viewaudit.php?viewaudit=<?=$row['auditname']?>'">&nbsp;
                </form>
                </td>
                <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
              </table>
                  </div>
                </section>
              </div>
          </div>
      </section>
    </section>      
<?php
    include 'footer.php';
    ?>