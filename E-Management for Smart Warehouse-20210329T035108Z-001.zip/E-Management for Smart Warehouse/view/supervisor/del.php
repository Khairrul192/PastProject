<?php
require_once '../../controller/supervisor/productController.php';

$product = new productController();

$product->buang($_GET['del'],$_GET['supplier']);


?>

