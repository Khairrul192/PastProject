<?php
require_once '../../model/clerk/categoryModel.php';

class categoryController{
    
    function add(){
        $category = new categoryModel();
        $category->catName = $_POST['catName'];
        if($category->addcategory() > 0){
            $message = "NEW CATEGORY ADDED!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/category.php';</script>";
        }
    }
    
    function addcat(){
        $category = new categoryModel();
        $category->catID = $_POST['cat'];
        $category->subcatName = $_POST['subcatName'];
        if($category->addsubcategory() > 0){
            $message = "NEW SUB CATEGORY ADDED!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/category.php';</script>";
        }
    }
    
    function view(){
        $category = new categoryModel();
        return $category->viewallcategory();
    }
    
    function viewcat(){
        $category = new categoryModel();
        return $category->viewallcategorys();
    }
   
    function delete(){
        $category = new categoryModel();
        $category->catID = $_POST['catID'];
        if($category->deletecategory()){
            $message = "Success Delete!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/category.php';</script>";
        }
    }
    
    function viewcategory(){
        $product = new categoryModel();
        return $product->viewallcategory();
    }
    
    function category(){//cascade addrack.php
        $category = new categoryModel();
        return $category->getCategory();
    }
    
    function Subcategory($categoryID){//cascade process.php
        $category = new categoryModel();
        return $category->getSubCategory($categoryID);
    }
    
    function getproduct($subcategoryID){//cascade process2.php
        $category = new categoryModel();
        return $category->getproduct($subcategoryID);
    }
    
    function addrack(){
        $category = new categoryModel();
        $category->category = $_POST['category'];
        $category->subcategory = $_POST['subcategory'];
        $category->placement = $_POST['placement'];
        $category->rackNo = $_POST['rack'];
        if($category->addrackNo()){
            $message = "Successfully Added!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/managerack.php';</script>";
        }
    }
    
    function viewrack(){
        $category = new categoryModel();
        return $category->viewrack();
    }
    
    function viewrack2(){
        $category = new categoryModel();
        return $category->viewrack2();
    }
    
    function delrack(){
        $category = new categoryModel();
        $category ->rack = $_POST['delrack'];
        if($category->deleterack()){
            $message = "Success Delete!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/managerack.php';</script>";
        }
    }
    
    function getrack($RackId,$SubcatId){//cascade process3.php
        $category = new categoryModel();
        return $category->getrack($RackId,$SubcatId);
    }
    
    function viewracks(){
        $category = new categoryModel();
        return $category->viewallrack();
    }
    
    function addprodrack(){
        $category = new categoryModel();
        $category->prodid = $_POST['product'];
        $category->rackid = $_POST['rack'];
        if($_POST['type']=="Warehouse"){
            if($category->addprodrack()){
              //$message = "Successfully Add!";
    		echo "<script type='text/javascript'>;
		window.location = '../../view/clerk/AddRack.php';</script>";  
            }
        }
        else{
        if($category->addprodrack2()){
           //$message = "Successfully Add!";
    		echo "<script type='text/javascript'>;
		window.location = '../../view/clerk/AddRack.php';</script>"; 
        }
        }
    }
    
    function viewprodrack(){
        $category = new categoryModel();
        return $category->viewallprodrack();
    }
    
    function viewprodrack2(){
        $category = new categoryModel();
        return $category->viewallprodrack2();
    }
    
    function delwarehouse(){
        $category = new categoryModel();
        $category->delware = $_POST['delware'];
        if($category->delwarehouse()){
            $message = "Success Delete!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/AddRack.php';</script>";
        }
    }
    
    function deldisp(){
        $category = new categoryModel();
        $category->deldisp = $_POST['deldisp'];
        if($category->deldisp()){
            $message = "Success Delete!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/AddRack.php';</script>";
        }
    }
    
}
