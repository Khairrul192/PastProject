<?php
require_once '../../controller/supervisor/productController.php';
$product = new productController();

if(isset($_POST['add'])){
    $data = $product->rcvitem();
}
?>
<html>
<head>
<style>
p.inline {display: inline-block;}
span { font-size: 13px;}
</style>
<style type="text/css" media="print">
    @page 
    {
        size: auto;   /* auto is the initial value */
        margin: 0mm;  /* this affects the margin in the printer settings */

    }
</style>
</head>
<body onload="window.print();">
	<div style="margin-left: 5%">
		<?php
		include 'barcode128.php';

		for($i=0;$i<sizeof($_POST['product']);$i++){
			$dataa = $product->viewitemprod($_POST['product'][$i]);
			foreach($dataa as $row1){
			echo "<p class='inline'><span ><b>Item: ".$row1['ProdName']."</b></span>".bar128(stripcslashes($row1['ProdCode']))."<span ><b>Price: ".$row1['ProdPrice']." </b><span></p>&nbsp&nbsp&nbsp&nbsp";
		}
		}

		?>
	</div>
</body>
</html>