<?php
include 'header.php';
require_once '../../controller/supervisor/productController.php';

$product = new productController;
$data = $product->viewbackstore();

?>
    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="icon_documents"></i>Adjustment</li>
            </ol>
          </div>
        </div>
          <input class="btn btn-primary" onclick="window.location.href='prodtransfer.php'" value="Transfer Item">
          <input class="btn btn-info" onclick="window.location.href='transfer.php'" value="Transfer History">
          <br><br>
          
          
          <div class="row">
              <div class="col-lg-12">
                <section class="panel">
                  <header class="panel-heading">
                    <i class="fa fa-thumbs-up"></i>Product List
                  </header>
                  <div class="panel-body">
                     
                      <!--table report-->
                      <table class="table table-striped table-advance table-hover">
                <thead>
                    <th>No</th>
                    <th>Code</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Retail Price</th>
                    <th>Display</th>
                    <th>Warehouse</th>
                    <th>Total</th> 
                </thead>
                <?php
                    $counter=1;
                    foreach($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"      
                        . "<td>".$row['ProdCode']."</td>"
                        . "<td>".$row['ProdName']."</td>"
                        . "<td>".$row['categoryName']."</td>"
                        . "<td> RM ".$row['ProdPrice']."</td>"
                        . "<td>".$row['Dqty']."</td>"
                        . "<td>".$row['Wqty']."</td>"
                        . "<td>".((int)$row['Wqty']+(int)$row['Dqty'])."</td>"
                                ?>
                  <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
              </table>
                  </div>
                </section>
              </div>
          </div>

          
      </section>
    </section>                  
  
<?php
include 'footer.php';
?>

