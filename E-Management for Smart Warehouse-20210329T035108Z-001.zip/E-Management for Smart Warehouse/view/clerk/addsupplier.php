<?php
include 'header.php';
require_once '../../controller/clerk/supplierController.php';

$supplier = new supplierController();

if(isset($_POST['add'])){
    $supplier->add();
}
?>
<body>
    
    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                <li><i class="fa fa-laptop"></i><a href="supplier.php">Supplier</a></li>
              <li><i class="fa fa-laptop"></i>Add Supplier</li>
            </ol>
          </div>
        </div>
    
    <!--supplier form start-->
                   <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Supplier Form
              </header>
              <div class="panel-body">
                <div class="form">
                  <form class="form-validate form-horizontal" method="POST" action="">
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Supplier Company <span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control" name="Suppcomp" type="text" required />
                      </div>
                    </div>
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Registration Number<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control" name="SRegNo" type="text" required />
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Email <span class="required">*</span></label>
                      <div class="col-lg-10">
                          <input class="form-control" name="email" type="email" required />
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Contact Number<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control" type="text" name="CNo" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required></td>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Account<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control" name="AccNo" type="text" required />
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Detail<span class="required">*</span></label>
                      <div class="col-lg-10">
                        <input class="form-control" id="subject" name="SuppDetail" type="text" required />
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                          <input class="btn btn-success" type="submit" name="add" value="Add">
                        <button class="btn btn-default" onclick="goBack()">Cancel</button>
                        <script>
                        function goBack() {
                          window.history.back();
                        }
                        </script>
                      </div>
                    </div>
                  </form>
                </div>

              </div>
            </section>
          </div>
        </div>
           <!--supplier form end-->
            </section>
          </div>
        </div>
    <!--main content end-->
  </section>
</body>

</html>