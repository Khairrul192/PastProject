<?php
include 'header.php';
require_once '../../controller/clerk/reportController.php';

$report = new reportController();
$data = $report->viewallorderreport();

?>

    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-table"></i>Vendor</li>
            </ol>
          </div>
        </div>
             <div class="row">
          <div class="col-sm-8">
            <section class="panel">
              <header class="panel-heading">
                Supplier
              </header>

              <table class="table">
                <thead>
                  <tr>
                    <th><i class=""></i>No</th>
                    <th><i class="icon_document"></i>Order</th>  
                    <th><i class="fa fa-truck"></i>Vendor</th>
                    <th><i class="fa fa-dashboard"></i>Date</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>
                <?php
                    $counter=1;
                    foreach($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"
                        . "<td>".$row['Ordno']."</td>"
                        . "<td>".$row['SuppCompany']."</td>"
                        . "<td>".$row['date']."</td>"
                        ?> 
                <td>
                <form action="" method="POST">
                    <input type="button" class="btn btn-primary" value="View Order" onclick="location.href='orderreport.php?vieworder=<?=$row['Ordno']?>'">&nbsp;
                </form>
                </td>
                <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
              </table>
              
            </section>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>   

<?php
include 'footer.php';
?>