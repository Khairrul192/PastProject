<?php
require_once '../../controller/clerk/categoryController.php';

$category = new categoryController();
$data = $category->Subcategory($_POST['id']);

?>
<option disabled selected value>Sub Category</option>
<?php
foreach($data as $row) {

		echo "<option value=".$row['SubCategoryID'].">".$row['SubCategoryName']."</option>";
}
?>