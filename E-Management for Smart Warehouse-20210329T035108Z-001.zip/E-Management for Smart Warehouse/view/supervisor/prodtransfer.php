<?php
include 'header.php';
require_once '../../controller/supervisor/productController.php';

$product = new productController();
$data = $product->viewallproduct();
if(isset($_POST['add'])){
    $product->transfertodisplay();
}
$view = $product->viewtransfer();
if(isset($_POST['transfer'])){
    $product->transfer();
}
if(isset($_POST['delete'])){
    $product->cancel();
}
?>
    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                <li><i class="icon_documents"></i><a href="adjustment.php">Adjustment</a></li>
              <li><i class="fa fa-laptop"></i>Display Transfer In</li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
              <form class="form-horizontal" method="POST" action="">
                    <div class="form-group ">
                        <table class="col-lg-7">
                            <tr>
                                <td align="center">      
                                    <label class="control-label"> Item Code </label>
                                </td>
                                <td>
                                    <select class="form-control" id="itemcode" name="code">
                                <option disabled selected value>Select Item</option>
                                <?php
                                foreach($data as $row){
                                    echo "<option value='".$row['ProdId']."'>".$row['ProdCode']." - ".$row['ProdName']."</option>";
                                }
                                ?>
                            </select>
                                </td>
                            </tr>
                            <tr>
                                <td align="center">      
                                    <label class="control-label"> Quantity</label>
                                </td>
                                <td><input class="form-control" name="qty" type="number"></td>
                                <td align="center"> <input class="btn btn-success" type="submit" name="add" value="Add"></td>
                            </tr>
                      </table>
                     </div>
                </form>
              <br>
              <ol class="breadcrumb">
                <li>Product Transfer List</li>
            </ol>
              <form action="" method="POST">
                  <table class="col-lg-5">
                        <tr>
                            <td align="center"><label class="control-label"> Transfer </label></td>
                            <td>
                                <select class="form-control" id="itemcode" name="type">
                                <option disabled selected value>Select Type</option>
                                    <option value="Store to display" >Store to display</option>
                                    <option value="Display to store" >Display to store</option>
                                </select>
                            </td>
                        </tr>
                  </table>
                  <br><br><br>
                  <div class="control-label col-lg-7">
            <section class="panel">
              <header class="panel-heading">
                Product List
              </header>
               
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th><i class=""></i>No</th>
                    <th><i class=""></i>Product Code</th>
                    <th><i class=""></i>Product Name</th>
                    <th><i class=""></i>Quantity</th>
                    <th><i class=""></i>Action</th>
                  </tr>
                </thead>
              <?php $counter=1;
                foreach ($view as $row) {
                    echo "<tr>"?>
                <td><?= $counter?></td>
                <td><?= $row['ProdCode']?>
                <input class="form-control" type="hidden" name="prodid[]" value="<?= $row['ProdId'] ?>" readonly</td></td>
                <td><?= $row['ProdName']?></td>
                <td><?= $row['transferqty']?>
                <input class="form-control" type="hidden" name="qty[]" value="<?= $row['transferqty'] ?>" readonly</td>
                <td>
                    <input type="hidden" name="prodtrans" value="<?=$row['transferid']?>"> <input type="submit" class="btn btn-danger" name="delete" value="Delete">&nbsp;
                </td>
                <?php
                echo "</tr>";
                $counter++;
               }
               ?>
                </table>
            </section> <input class="btn btn-primary" type="submit" name="transfer" value="Transfer">
                  </div></form>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>
<?php
include 'footer.php';
?>
