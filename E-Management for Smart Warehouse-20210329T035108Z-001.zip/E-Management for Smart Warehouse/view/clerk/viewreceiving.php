<?php
include 'header.php';
require_once '../../controller/supervisor/orderController.php';

$Sorder = new SorderController();
$view = $Sorder->viewinvoice($_GET['invoice']);
?>

    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                <li><i class="fa fa-table"></i><a href="receivingreport.php">Invoice</a></li>
              <li><i class="icon_document"></i>Invoice List</li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
              <form action="" method="POST">
            <section class="panel">
              <header class="panel-heading">
                Category List
              </header>
               
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th>No</th> 
                    <th>Item Code </th>
                    <th>Item Name </th>
                    <th>Order</th>
                    <th>Receive</th>
                    <th>Retail Price</th>

                  </tr>
                </thead>
                <?php
                $counter=1;
                foreach($view as $row){
                    echo "<tr>"?>                    
                    <td><?= $counter ?></td>                    
                    <td><?= $row['ProdCode']?></td>                    
                    <td><?= $row['ProdName'] ?></td> 
                    <td><?= $row['ordqty'] ?></td> 
                    <td><?= $row['Invqty'] ?></td>                                     
                    <td> RM <?= ((int)$row['Invqty']*(float)$row['ProdPrice']) ?></td>                                    
                <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
              </table>                     
            </section>       
                <input type="button" class="btn btn-success" value="Print">&nbsp;
                <input type="button" class="btn btn-default" onclick="location.href='receivingreport.php'" value="Back">       
                </form>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>
<?php
include 'footer.php';
?>
