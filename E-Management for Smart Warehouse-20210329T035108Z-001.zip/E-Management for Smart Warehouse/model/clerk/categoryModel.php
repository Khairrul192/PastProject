<?php
require_once '../../library/database.php';

class categoryModel{
    public $catID,$catName,$min,$max,$rackno,$rackid,$wqty,$catid,$prodid,$subcatName,$category,$subcategory,$rackNo,$placement,$SubcatId;
    
    function addcategory(){
        $sql = "insert into category (categoryName) values(:catName)";
        $args = [':catName'=>$this->catName];
        $stmt = DB::run($sql, $args);
        $count = $stmt->rowCount();
        return $count;
    }
        
    function addsubcategory(){
        $sql = "insert into subcategory (SubCategoryName,categoryID) values(:subcatName,:catName)";
        $args = [':subcatName'=>$this->subcatName,':catName'=>$this->catID];
        $stmt = DB::run($sql, $args);
        $count = $stmt->rowCount();
        return $count;
    }
    
    function addrackNo(){
        $sql = "insert into rack (categoryID,SubCategoryID,rackno,type) values(:catid,:subcatid,:rackno,:type)";
        $args = [':catid'=>$this->category,':subcatid'=>$this->subcategory, ':rackno'=>$this->rackNo, ':type'=>$this->placement];
        $stmt = DB::run($sql, $args);
        $count = $stmt->rowCount();
        return $count;
    }
    
    function viewallcategory(){
        $sql = "select * from subcategory,category where subcategory.categoryID=category.categoryID order by categoryName asc";
        return DB::run($sql);
    }
    
    function viewallcategorys(){
        $sql = "select * from category order by categoryName asc";
        return DB::run($sql);
    }
  
    function deletecategory(){
        $sql = "delete from subcategory where SubCategoryID=:delcat";
        $args = [':delcat'=>$this->catID];
        return DB::run($sql,$args);
    }
    
//    function viewallproduct(){
//        $sql= "insert into warehouse (WHId,ProdId, categoryID) values (:rackno, prodid, catid)";
//        $args = [':rackno'=>$this->rackno, ':prodid'=>$this->prodid, ':catid'=>$this->catid];
//    }
    
    function getCategory(){
        $sql = "select * from category";
        return DB::run($sql);
    }
    
    function getSubCategory($categoryID){
        $sql = "select * from subcategory where categoryID=:categoryID";
        $args = [':categoryID'=> $categoryID];
        return DB::run($sql, $args);
    }
    
    function getproduct($subcategoryID){
        $sql = "select * from product where SubCategoryID=:subcategoryID";
        $args = [':subcategoryID'=> $subcategoryID];
        return DB::run($sql, $args);
    }
    
    function viewrack(){
        $sql = "select * from rack,category,subcategory where rack.categoryID=category.categoryID and rack.SubCategoryID=subcategory.SubCategoryID and type='warehouse' order by rackno asc";
        return DB::run($sql);
    }
    
    function viewrack2(){
        $sql = "select * from rack,category,subcategory where rack.categoryID=category.categoryID and rack.SubCategoryID=subcategory.SubCategoryID and type='display' order by rackno asc";
        return DB::run($sql);
    }
    
    function deleterack(){
        $sql = "delete from rack where RackId=:delrack";
        $args = [':delrack'=>$this->rack];
        return DB::run($sql,$args);
    }
    
    function getrack($RackId,$SubcatId){
        $sql = "select * from rack where type=:RackId and SubCategoryID=:SubcatId group by rackno";
        $args = [':RackId'=> $RackId,':SubcatId'=> $SubcatId];
        return DB::run($sql, $args);
    }
    
    function viewallrack(){
        $sql = "select distinct type from rack";
        return DB::run($sql);
    }
    
    function addprodrack(){
        $sql = "insert into warehouse (ProdId,RackId) values(:prodid,:rackid)";
        $args = [':prodid'=>$this->prodid,':rackid'=>$this->rackid];
        $stmt = DB::run($sql, $args);
        $count = $stmt->rowCount();
        return $count;
    }
    
    function addprodrack2(){
        $sql = "insert into display (ProdId,RackId) values(:prodid,:rackid)";
        $args = [':prodid'=>$this->prodid,':rackid'=>$this->rackid];
        $stmt = DB::run($sql, $args);
        $count = $stmt->rowCount();
        return $count;
    }
    
    function viewallprodrack(){
        $sql = "select * from warehouse,rack,product,category,subcategory where warehouse.RackId=rack.RackId and warehouse.ProdId=product.ProdId and product.categoryID=category.categoryID and product.SubCategoryID=subcategory.SubCategoryID order by rackno asc";
        return DB::run($sql);
    }
    
    function viewallprodrack2(){
        $sql = "select * from display,rack,product,category,subcategory where display.RackId=rack.RackId and display.ProdId=product.ProdId and product.categoryID=category.categoryID and product.SubCategoryID=subcategory.SubCategoryID order by rackno asc";
        return DB::run($sql);
    }
    
    function delwarehouse(){
        $sql = "delete from warehouse where warehouseId=:delware";
        $args = [':delware'=>$this->delware];
        return DB::run($sql,$args);
    }
    
    function deldisp(){
        $sql = "delete from display where DispId=:deldisp";
        $args = [':deldisp'=>$this->deldisp];
        return DB::run($sql,$args);
    }
        
}