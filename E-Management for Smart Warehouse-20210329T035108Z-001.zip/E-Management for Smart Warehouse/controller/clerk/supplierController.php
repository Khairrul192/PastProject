<?php
require_once '../../model/clerk/supplierModel.php';

class supplierController{
    
    function add(){
        $supplier = new supplierModel();
        $supplier->SuppComp = $_POST['Suppcomp'];
        $supplier->email = $_POST['email'];
        $supplier->CNo = $_POST['CNo'];
        $supplier->AccNo = $_POST['AccNo'];
        $supplier->SRegNo = $_POST['SRegNo'];
        $supplier->SuppDetail = $_POST['SuppDetail'];
        
        if($supplier->addsupplier() > 0){
            $message = "NEW SUPPLIER ADDED!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/supplier.php';</script>";
        }
    }
    
    function view(){
        $supplier = new supplierModel();
        return $supplier->viewallsupplier();
    }
    
    function viewsupp($viewSupp){
        $supplier = new supplierModel();
        $supplier->SRegNo = $viewSupp;
        return $supplier->viewsupplier();
    }
    
    function editsupplier(){
        $supplier = new supplierModel();
        $supplier->SRegNo = $_POST['SRegNo'];
        $supplier->SuppComp = $_POST['Suppcomp'];
        $supplier->email = $_POST['email'];
        $supplier->CNo = $_POST['CNo'];
        $supplier->AccNo = $_POST['AccNo'];
        $supplier->SuppDetail = $_POST['SuppDetail'];
        if($supplier->modifysupplier()){
            $message = "Success Update!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/viewsupp.php?viewsupplier=".$_POST['SRegNo']."';</script>";
        }
    }
    
    function delete(){
        $supplier = new supplierModel();
        $supplier->SRegNo = $_POST['SRegNo'];
        if($supplier->deletesupplier()){
            $message = "Success Delete!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/supplier.php';</script>";
        }
    }
    
}
