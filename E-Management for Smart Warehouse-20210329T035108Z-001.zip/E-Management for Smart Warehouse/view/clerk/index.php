<?php
require_once 'header.php';
?>

<body>
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
          </div>
        </div>
    </section>
    <!--main content end-->
<center><h2>Welcome</h2></center>
    
    <br>
    <center><table>
        <tr>
            <td><center><img src="../img/rcv.png" width="100" height="100"></center><div>
                <input class="btn btn-primary" onclick="location.href='supplier.php'" value="Supplier"></td>
                <td><center><img src="../img/adjust.png" width="100" height="100"></center><div>
                <input class="btn btn-primary" onclick="location.href='payment.php'" value="Payment"></td>
                <td><center><img src="../img/category.png" width="100" height="100"></center><div>
                <input class="btn btn-primary" onclick="location.href='category.php'" value="Category"></td>
                
        </tr>
        </table></center>
    <br>
    <center>
        <table>
        <tr>
            <td><center><img src="../img/cord.png" width="100" height="100"></center><div>
                <input class="btn btn-primary" onclick="location.href='orderreport.php'" value="Invoice Report"></td>
                <td><center><img src="../img/return.png" width="100" height="100"></center><div>
                <input class="btn btn-primary" onclick="location.href='return.php'" value="Return Report"></td>
                <td><center><img src="../img/category.png" width="100" height="100"></center><div>
                <input class="btn btn-primary" onclick="location.href='writeoffreport.php'" value="Write off Report"></td>
                <td><center><img src="../img/audit.png" width="100" height="100"></center><div>
                <input class="btn btn-primary" onclick="location.href='auditlist.php'" value="Audit Report"></td>
        </tr>
        </table>
    </center>

    </section>
<?php
include 'footer.php';
?>