<?php
require_once 'header.php';
require_once '../../controller/clerk/supplierController.php';
$supplier = new supplierController();
$data = $supplier->view();
if(isset($_POST['delete'])){
    $supplier->delete();
}
?>
    <!--main content start-->
<section id="main-content">
      <section class="wrapper">      
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-truck"></i>Supplier</li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Supplier
              </header>
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th><i class="icon_profile"></i> Company</th>
                    <th><i class="icon_mail_alt"></i> Email</th>
                    <th><i class="icon_mobile"></i> Mobile</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>               
                    <?php
                    foreach($data as $detail){
                       echo "<tr>"
                        . "<td>".$detail['SuppCompany']."</td>"
                        . "<td>".$detail['SuppEmail']."</td>"
                        . "<td>".$detail['SuppCNo']."</td>";
                       ?>
                    <td><form action="" method="POST">
                            <input type="button" class="btn btn-success" onclick="location.href='viewsupp.php?viewsupplier=<?=$detail['RegNo']?>'" value="View">&nbsp;
                            <input type="hidden" name="SRegNo" value="<?=$detail['RegNo']?>"> <input type="submit" class="btn btn-danger" name="delete" value="Delete">&nbsp;
                        </form></td>
                      <?php
                     echo "</tr>";
                    }
                    ?>
              </table>
              
            </section>
          </div>
        </div>
          <div><a class="btn btn-info" href="addsupplier.php">New Supplier</a></div></div>
    </section>
    <!--main content end-->
</section>

<?php
include 'footer.php';
?>
