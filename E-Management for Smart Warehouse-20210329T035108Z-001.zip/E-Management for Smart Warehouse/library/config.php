<?php
//database setting

//define constant to store database setting

define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'ispsm');
define('DB_USER', 'root');
define('DB_PASS', '');
?>