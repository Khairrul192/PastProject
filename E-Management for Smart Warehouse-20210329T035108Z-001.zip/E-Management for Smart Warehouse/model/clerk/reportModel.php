<?php
require_once '../../library/database.php';

class reportModel{
    
    function allorderreport(){
         $sql = "select distinct(ordrpt.RegNo),ordrpt.date,ordrpt.Ordno,supplier.* from ordrpt,supplier where ordrpt.RegNo = supplier.RegNo";
        return DB::run($sql);
    }
    
    function listorderreport(){
        $sql = "select * from ordrpt,product where ordrpt.ProdId = product.ProdId and ordrpt.Ordno=:ordref";
        $args = [':ordref'=>$this->ordref];
        return DB::run($sql,$args);
    }
    
    function invoice2(){
        $sql = "select * from invoice,product where invoice.ProdId = product.ProdId and invoice.RefNo=:refno";
        $args = [':refno'=>$this->refno];
        return DB::run($sql,$args);
    }
}

