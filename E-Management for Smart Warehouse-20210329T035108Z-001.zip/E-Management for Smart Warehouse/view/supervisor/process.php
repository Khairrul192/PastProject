<?php
require_once '../../controller/supervisor/adjustmentController.php';

$prod = new adjustmentController();
$data = $prod->getrackNo($_POST['id']);

?>
<option disabled selected value>Select Rack</option>
<?php
foreach($data as $row) {
    if($_POST['id'] == "warehouse"){
            echo "<option value='".$row['RackNo']."'>".$row['RackNo']."</option>";
        }
        if($_POST['id'] == "display"){
            echo "<option value='".$row['rackNo']."'>".$row['rackNo']."</option>";
        }
}
?>