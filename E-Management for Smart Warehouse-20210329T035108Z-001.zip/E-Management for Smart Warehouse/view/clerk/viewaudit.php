<?php
include 'header.php';
require_once '../../controller/supervisor/adjustmentController.php';

$product = new adjustmentController();
$view = $product->audititem($_GET['viewaudit']);
?>

    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="icon_documents"></i>Audit</li>
              <li><i class="icon_document"></i>Audit Report</li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
              <form action="" method="POST">
            <section class="panel">
              <header class="panel-heading">
                Category List
              </header>
               
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th>No</th> 
                    <th>Code</th>
                    <th>Name</th>
                    <th>Counted Warehouse</th>
                    <th>Warehouse System Quantity</th>
                    <th>Counted Display</th>
                    <th>Display System Quantity</th>
                    <th>Overall Count Quantity</th>
                    <th>Overall System Quantity</th>
                    <th>Difference</th>
                    <th>Loss</th>
                  </tr>
                </thead>
                <?php
                $counter=1;
                foreach($view as $row){
                    echo "<tr>"?>                    
                    <td><?= $counter ?></td>                    
                    <td><?= $row['prodcode']?></td>                    
                    <td><?= $row['prodname'] ?></td>                    
                    <td><?= $row['Wqty'] ?></td>
                    <td><?= $row['Wsqty']?></td>                    
                    <td><?= $row['Dqty'] ?></td>                    
                    <td><?= $row['Dsqty'] ?></td> 
                    <td><?= $row['Ocqty']?></td>                    
                    <td><?= $row['Osqty'] ?></td>                    
                    <td><?= $row['differ'] ?></td> 
                    <td><?= $row['loss'] ?></td>                
                <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
              </table>                     
            </section>       
                <input type="button" class="btn btn-success" value="Print">&nbsp;
                <input type="button" class="btn btn-default" onclick="location.href='auditreport.php'" value="Back">       
                </form>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>
<?php
include 'footer.php';
?>
