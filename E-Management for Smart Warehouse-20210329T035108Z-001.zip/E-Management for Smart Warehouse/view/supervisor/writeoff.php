<?php
include 'header.php';
require_once '../../controller/supervisor/productController.php';
$product = new productController();
$data = $product-> viewallproduct();
$view = $product-> viewRmvProd();
if(isset($_POST['add'])){
    $product->addprod();
}
if(isset($_POST['writeoff'])){
    $product->submit();
}
?>

    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-laptop"></i>Write Off</li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-12">
              <form class="form-horizontal" method="POST" action="">
                    <div class="form-group ">
                        <table class="col-lg-7">
                            <tr>
                                <td align="center">      
                                    <label class="control-label"> Item Code </label>
                                </td>
                                <td>
                                    <select class="form-control" id="itemcode" name="code">
                                <option disabled selected value>Select Item</option>
                                <?php
                                foreach($data as $row){
                                    echo "<option value='".$row['ProdId']."'>".$row['ProdCode']." - ".$row['ProdName']."</option>";
                                }
                                ?>
                            </select>
                                </td>
                            </tr>
                            <tr>
                                <td align="center">      
                                    <label class="control-label"> Quantity</label>
                                </td>
                                <td>
                                    <input class="form-control" name="qty"  required />
                                </td>
                            </tr>
                            <tr>
                                <td align="center">      
                                    <label class="control-label"> Reason</label>
                                </td>
                                <td>
                                    <select class="form-control" id="reason" name="reason">
                                        <option disabled selected value>Select Reason</option>
                                        <option value="Damage">Damage</option>
                                        <option value="Expired">Expired</option>
                                    </select>
                                </td>                                
                                <td align="center"> <input class="btn btn-success" type="submit" name="add" value="Add"></td>
                            </tr>
                        </table>
                     </div>
                </form>
              <br>
              <ol class="breadcrumb">
                <li>Product Write Off List</li>
            </ol>
              <form action="" method="POST">
            <section class="panel">
              <header class="panel-heading">
                Category List
              </header>
               
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th>No</th> 
                    <th>Item Code </th>
                    <th>Item Name </th>
                    <th>Quantity</th>
                    <th>Sales Price</th>
                    <th>Retail Price</th>
                    <th>Reason</th>
                    <th>Loss</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <?php
                $counter=1;
                foreach($view as $row){
                    echo "<tr>"?>
                    
                    <td><?= $counter ?></td>
                    
                    <td><?php echo $row['ProdCode']?>
                        <input class="form-control" type="hidden" name="prodid[]" value="<?php echo $row['ProdId'] ?>"></td>
                    
                    <td><?= $row['ProdName'] ?></td>
                    
                    <td><?= $row['WoQty'] ?>
                        <input class="form-control" type="hidden" name="qty[]" value="<?= $row['WoQty'] ?>" readonly</td>
                    
                    <td><?= sprintf("%.2f",(float)$row['ProdPrice']*1.1)?></td>
                    
                    <td><?= $row['ProdPrice'] ?></td>
                    
                    <td><?= $row['reason'] ?>
                        <input class="form-control" type="hidden" name="rreason[]" value="<?= $row['reason'] ?>"></td>
                    
                    <td><?= (int)$row['WoQty']*(float)$row['ProdPrice']?></td>     
                <td>
                    <input type="button" onclick="window.location.href='delete.php?param=<?= $row['WOId']?>'" class="btn btn-danger" name="delete" value="Delete">&nbsp;
                </td>              
                <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
              </table>                     
            </section>       
              
                  <table>
                      <tr>
                      <td align="center">      
                          <label class="control-label"> Reference No </label>
                      </td>
                      <td>
                          <input class="form-control" name="Reference" type="text" value="<?=(mt_rand())?>" readonly/>
                      </td>                      
                      </tr>
                  </table><br>
               <input type="submit" class="btn btn-primary" name="writeoff" value="Submit">
               </form>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>
<?php
include 'footer.php';
?>
