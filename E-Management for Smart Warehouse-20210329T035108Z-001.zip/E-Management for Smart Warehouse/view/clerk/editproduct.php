<?php
require_once '../..//controller/clerk/prodController.php';
require_once 'header.php';

$editProd = $_GET['editprod'];

$product = new ProdController();
$data = $product->viewprod($editProd);

if(isset($_POST['update'])){
    $product->editprod();
}

?>

<body>
    
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                <li><i class="fa fa-truck"></i><a href="supplier.php">Supplier</a></li>
                <li><i class="fa fa-bars"></i><a href="supplierprod.php">Supplier Products</a></li>
              <li><i class="fa fa-bars"></i>Edit Product</li>
            </ol>
          </div>
        </div>
    
    <!--product form start-->
        <div class="row">
          <div class="col-lg-7">
            <section class="panel">
              <header class="panel-heading">
                Supplier Product
              </header>
              <div class="panel-body">
                <div class="form">
                  <form class="form-validate form-horizontal" method="POST" action="">
                    <div class="form-group ">
                        <?php
                        foreach($data as $detail){
                        ?>
                      <label class="control-label col-lg-2">Code</label>
                      <div class="col-lg-7">
                          <input type="hidden" name="regno" value="<?=$detail['RegNo']?>" readonly>
                          <input type="hidden" name="ProdId" value="<?=$detail['ProdId']?>" readonly>
                        <input class="form-control" name="prodCode" value="<?=$detail['ProdCode']?>" type="text" readonly />
                      </div>
                    </div>
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Name<span class="required">*</span></label>
                      <div class="col-lg-7">
                        <input class="form-control" name="prodName" value="<?=$detail['ProdName']?>" type="text" readonly/>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Retail Price</label>
                      <div class="col-lg-7">
                          <input class="form-control" name="prodPrice" value="<?=$detail['ProdPrice']?>" type="float" />
                      </div>
                    </div>
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Category</label>
                      <div class="col-lg-7">
                          <input class="form-control" name="cat" value="<?=$detail['categoryName']?>" readonly/>
                      </div>
                    </div>
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Rack No</label>
                      <div class="col-lg-7">
                          <input class="form-control" name="rackno" value="<?=$detail['RackNo']?>">
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                          <input class="btn btn-success" type="submit" name="update" value="Update">
                        <input type="button" class="btn btn-default" onclick="location.href='supplierprod.php?param=<?=$detail['RegNo']?>'" value="BACK">
                      </div>
                    </div>
                  </form>
                </div>
<?php } ?>
              </div>
            </section>
          </div>
        </div>
           <!--supplier form end-->
            </section>
    <!--main content end-->
  </section>
</body>
<?php
include 'footer.php';
?>