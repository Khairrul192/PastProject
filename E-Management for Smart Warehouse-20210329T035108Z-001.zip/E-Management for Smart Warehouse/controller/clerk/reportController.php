<?php
require_once '../../model/clerk/reportModel.php';

class reportController{
    
   function viewallorderreport(){
        $report = new reportModel();
        return $report->allorderreport();
    }
    
    function orderlistreport($vieworder){
        $report = new reportModel();
        $report->ordref = $vieworder;
        return $report->listorderreport();
    }
    
    function viewinvoice2($payment){
        $Sorder = new reportModel();
        $Sorder->refno = $payment;
        return $Sorder->invoice2();
    }
    
}