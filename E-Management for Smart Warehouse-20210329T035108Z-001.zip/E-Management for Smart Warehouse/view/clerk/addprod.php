<?php
require_once 'header.php';
require_once '../../controller/clerk/prodController.php';

$product = new ProdController();
$cat = $product->viewcategory();
$supp = $product ->viewsupplier();

if(isset($_POST['add'])){
    $product->addprod();
}
?>

<body>
    
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-bars"></i>Add Product</li>
            </ol>
          </div>
        </div>
    
    <!--product form start-->
        <div class="row">
          <div class="col-lg-7">
            <section class="panel">
              <header class="panel-heading">
                Supplier Product
              </header>
              <div class="panel-body">
                <div class="form">
                  <form class="form-validate form-horizontal" method="POST" action="">
                    
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Category*</label>
                      <div class="col-lg-7">
                          <select class="form-control" id="category" name="category" required>
                                <option disabled selected value>Select Category</option>
                                <?php
                                foreach($cat as $view){
                                    echo "<option value='".$view['categoryID']."'>".$view['categoryName']."</option>";
                                }
                                ?>
                            </select>
                      </div></div>
                      
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Sub Category*</label>
                      <div class="col-lg-7">
                          <select class="form-control" id="subcategory" name="subcategory" required>
                                <option disabled selected value>Select Sub Category</option>
                            </select>
                          
<script language="JavaScript" type="text/javascript" src="jquery-1.11.1.min.js"></script>
<script>
function select_cir(id) {
    $.ajax({
                    type : "POST",
                    data : {id:id},
                    url : "addproductcascade.php",
                    success : function (res2) {
                            //alert(res2);
                            $('#subcategory').append(res2);
                    },
                    //error:function (res2){
                            //alert("error");}
            });
}

$(document).ready(function(e) {
$("#category").on("change",function() {
    var id = document.getElementById("category").value;
    document.getElementById("subcategory").options.length=0;
    select_cir(id);
});
});
</script>
                          
                      </div>
                    </div>
                      
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Code <span class="required">*</span></label>
                      <div class="col-lg-7">
                        <input class="form-control" name="prodCode" type="text" required />
                      </div>
                    </div>
                      
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Name<span class="required">*</span></label>
                      <div class="col-lg-7">
                        <input class="form-control" name="prodName" type="text" required />
                      </div>
                    </div>
                      
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Retail Price<span class="required">*</span></label>
                      <div class="col-lg-7">
                          <input class="form-control" name="prodPrice" type="float" required />
                      </div>
                    </div>
                      
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Supplier*</label>
                      <div class="col-lg-7">
                          <select class="form-control" id="supplier" name="supplier" required>
                                <option disabled selected value>Select Supplier</option>
                                <?php
                                foreach($supp as $sup){
                                    echo "<option value='".$sup['RegNo']."'>".$sup['SuppCompany']."</option>";
                                }
                                ?>
                            </select>
                      </div></div>
                      
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                          <input class="btn btn-success" type="submit" name="add" value="Add">
                        <button class="btn btn-default" onclick="goBack()">Cancel</button>
                        
                        <script>
                        function goBack() {
                          window.history.back();
                        }
                        </script>
                      </div>
                    </div>
                  </form>
                </div>

              </div>
            </section>
          </div>
        </div>
           <!--supplier form end-->
            </section>
    <!--main content end-->
  </section>

</body>
<?php
include 'footer.php';
?>