<?php
require_once '../../controller/clerk/categoryController.php';

$category = new categoryController();
$data = $category->getproduct($_POST['idsub']);

?>
<option disabled selected value>Product</option>
<?php
foreach($data as $row) {

		echo "<option value=".$row['ProdId'].">".$row['ProdName']."</option>";
}
?>