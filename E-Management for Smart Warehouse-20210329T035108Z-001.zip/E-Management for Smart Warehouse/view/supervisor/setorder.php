<?php
require_once 'header.php';
require_once '../../controller/supervisor/orderController.php';

$Sorder = new SorderController();
$data = $Sorder->vieworder();

if(isset($_POST['addorder'])){
    $Sorder->createorder();
}

?>

    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-table"></i>Order</li>
              <li><i class="fa fa-table_alt"></i>Order Confirmation</li>
            </ol>
          </div>
        </div>
             <div class="row">
          <div class="col-sm-7">
              <?php $i =0;
                foreach ($data as $row) {
                   
                    ?>
                <section class="panel">
                  <form action="" method="POST">
              <header class="panel-heading">
                <input type="checkbox" name="order[]" value="yes">
                <?php
                    echo $row['SuppCompany'];?>
                    <input class="form-control" type="hidden" name="suppid[]" value="<?php echo $row['RegNo'] ?>"></td>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  Order No: 
                  <?php $orderRef = mt_rand()?>
                  <input name="ordref[]" value="<?=$orderRef?>" type="hidden" readonly/>
                  <?php echo $orderRef ?>
              </header>
              <table class="table">
                <thead>
                  <tr>
                    <th><i class=""></i>No</th>
                    <th>Product</th>  
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                  </tr>
                </thead>
                <?php
                $counter=1;
                $dataa = $Sorder->vieworder1($row['RegNo']);
                foreach ($dataa as $row) {
                        echo "<tr>"
                        . "<td>".$counter."</td>"?>
                        <td><?php echo $row['ProdName']?>
                        <input class="form-control" type="hidden" name="prodid<?=$i?>[]" value="<?php echo $row['ProdId'] ?>"></td>
                        <?= "<td>".$row['ProdPrice']."</td>"?>
                        <td><?php echo $row['qty']?>
                        <input class="form-control" type="hidden" name="qty<?=$i?>[]" value="<?php echo $row['qty'] ?>"></td>
                        <td>RM <?=sprintf("%.2f", (int)$row['qty']*(float)$row['ProdPrice'])?></td>
                <?php
                     echo "</tr>";
                     $counter++;
                }
                    ?>
              </table>
                </section>
                             <input type="hidden" class="btn btn-primary" value="<?=$i?>" name="addorder1[]">&nbsp;
              <?php
                $i++;}
                ?>
              <input type="submit" class="btn btn-primary" value="Release Order" name="addorder">&nbsp;
              <br><br>
              </form> 
          </div>
        </div>
          <form>
              <input type="button" class="btn btn-default" onclick="location.href='orderlist.php'" value="Back"> 
              </form>
      </section>
        
    <!--main content end-->
  </section>   

<?php
include 'footer.php';
?>