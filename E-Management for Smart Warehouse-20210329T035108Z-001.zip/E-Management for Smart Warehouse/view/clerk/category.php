<?php
require_once 'header.php';
require_once '../../controller/clerk/categoryController.php';

$category = new categoryController();
$data = $category->view();
$cat = $category->viewcat();

if(isset($_POST['delete'])){
    $category->delete();
}

if(isset($_POST['add'])){// add category
   $category->add();
}
if(isset($_POST['addcat'])){// add sub category
   $category->addcat();
}
?>

    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-laptop"></i>Category</li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-6">
              <form class="form" method="POST" action="">
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Category</label>
                      <div class="col-lg-4">
                          <input class="form-control" name="catName" type="text" required />
                      </div>
                     </div>
                  <input class="btn btn-info" type="submit" name="add" value="Add Category">
                </form>
          </div>
            <div class="col-lg-6">
                <br>
              <form class="form" method="POST" action="">
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Category</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="Category" name="cat">
                                <option disabled selected value>Select Category</option>
                                <?php
                                foreach($cat as $view){
                                    echo "<option value='".$view['categoryID']."'>".$view['categoryName']."</option>";
                                }
                                ?>
                            </select>
                      </div><br><br>
                      <label class="control-label col-lg-2">Sub Category</label>
                      <div class="col-lg-4">
                          <input class="form-control" name="subcatName" type="text" required />
                      </div>
                      <input class="btn btn-info" type="submit" name="addcat" value="Add Sub Category">
                    </div>
                </form>
            </div>
          </div>
              </div>
        <div class="row">
           <div class="col-lg-12">
              <br>
            <section class="panel">
              <header class="panel-heading">
                Category List
              </header>
                
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th><i class=""></i>No</th> 
                    <th><i class="icon_cart_alt"></i> Category</th>
                    <th><i class="icon_cart"></i> Sub - Category</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>
                <?php
                    $counter=1;
                    foreach($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"
                        . "<td>".$row['categoryName']."</td>"
                        . "<td>".$row['SubCategoryName']."</td>"
                        ?>
                    <td><form action="" method="POST">
                            <input type="hidden" name="catID" value="<?=$row['SubCategoryID']?>"> <input type="submit" class="btn btn-danger" name="delete" value="Delete">
                        </form></td>
                        <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
              </table>
              
            </section>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>

<?php
include 'footer.php';
?>
