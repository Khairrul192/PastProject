<?php
include 'header.php';
require_once '../../controller/supervisor/productController.php';

$product = new productController();
$data = $product->viewrmvitem();

?>

    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-table"></i>Product Removal</li>
            </ol>
          </div>
        </div>
             <div class="row">
          <div class="col-sm-6">
              
              <input class="btn btn-info" onclick="window.location.href='writeoff.php'" value="Create Removal">
              <br><br>  
            <section class="panel">
              <header class="panel-heading">
                Removal History
              </header>

              <table class="table">
                <thead>
                  <tr>
                    <th><i class=""></i>No</th>
                    <th><i class="icon_document"></i>Reference No</th>  
                    <th><i class="fa fa-truck"></i>Date</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>
                <?php
                    $counter=1;
                    foreach($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"
                        . "<td>".$row['reference']."</td>"
                        . "<td>".$row['worptdate']."</td>"
                        ?> 
                <td>
                <form action="" method="POST">
                    <input type="button" class="btn btn-primary" value="View" onclick="location.href='viewwriteoff.php?viewwriteoff=<?=$row['reference']?>'">&nbsp;
                </form>
                </td>
                <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
              </table>
              
            </section>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>   

<?php
include 'footer.php';
?>