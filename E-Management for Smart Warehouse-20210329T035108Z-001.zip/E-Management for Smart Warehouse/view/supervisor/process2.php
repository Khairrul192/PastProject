<?php
require_once '../../controller/supervisor/orderController.php';

$Sorder = new SorderController();
$data = $Sorder->Subcategory($_POST['id']);

?>
<option disabled selected value>Sub Category</option>
<?php
foreach($data as $row) {

		echo "<option value=".$row['SubCategoryID'].">".$row['SubCategoryName']."</option>";
}
?>