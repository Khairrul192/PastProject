<?php
include '../../library/database.php';

class userModel{
  
    public $id,$pass,$name,$email,$phono,$add,$role, $ClerkId, $SvId;
    
    function register(){
        if($this->role == "clerk"){
        $query = "insert into clerk(ClerkId, ClerkPwd, ClerkName, ClerkEmail, ClerkPNo, ClerkAdd) values(:id, :pass, :name, :email, :phono, :add)";
        $param = [':id' => $this->id,':pass'=>$this->pass,':name'=>$this->name, ':email'=>$this->email, ':phono' => $this->phono, ':add' => $this->add];
        $result = DB::run($query, $param);
        $cek = $result->rowCount();
        return $cek;
        } else
        if($this->role == "supervisor"){
        $query = "insert into supervisor(SvId, SvPwd, SvName, SvEmail, SvPNo, SvAdd) values(:id, :pass, :name, :email, :phono, :add)";
        $param = [':id' => $this->id,':pass'=>$this->pass,':name'=>$this->name, ':email'=>$this->email, ':phono' => $this->phono, ':add' => $this->add];
        $result = DB::run($query, $param);
        $cek = $result->rowCount();
        return $cek;
        }
    }
    
    function viewallclerk(){
        $sql = "select * from clerk";
        return DB::run($sql);
    }
    
    function viewallsupervisor(){
        $sql = "select * from supervisor";
        return DB::run($sql);
    }
    
    function viewsupervisor(){
        $sql = "select * from supervisor where SvId=:viewSV";
        $args = [':viewSV'=>$this->id];
        return DB::run($sql,$args);
    }
    
    function viewclerk(){
        $sql = "select * from clerk where ClerkId=:viewCL";
        $args = [':viewCL'=>$this->id];
        return DB::run($sql,$args);
    }
    
    function svdel(){
        $sql = "delete from supervisor where SvId=:SvId";
        $args = [':SvId'=>$this->SvId];
        return DB::run($sql,$args);
    }
    
    function cldel(){
        $sql = "delete from clerk where ClerkId=:ClerkId";
        $args = [':ClerkId'=>$this->ClerkId];
        return DB::run($sql,$args);
    }


}
?>