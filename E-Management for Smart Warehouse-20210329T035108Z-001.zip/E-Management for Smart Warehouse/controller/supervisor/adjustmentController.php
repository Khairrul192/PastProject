<?php
require_once '../../model/supervisor/adjustmentModel.php';

class adjustmentController {

    function viewbackstore() {
        
        $product = new adjustmentModel();
        return $product ->viewstoreitem();
        
    }
    
//    function getrackNo($key){
//        if($key == "warehouse"){
//            return adjustmentModel::getwarehouserackNo();
//        }
//        if($key == "display"){
//            return adjustmentModel::getdisplayrackNo();
//        }
//    }
//
//    function getData(){
//        $prod = new adjustmentModel();
//        $prod->tblname = $_POST['itemcode'];
//        $prod->rackno = $_POST['rackno'];
//        if($_POST['itemcode'] == "warehouse"){
//            if($prod->warehouseitem()){
//        }
//        
//        else {
//            if($prod->displayitem()){
//        }
//    }
//        }
//    }
    
    function viewproduct() {
        $product = new adjustmentModel();
        return $product ->viewarehouse();
    }
    
    function getwarehouseitem() {
        $product = new adjustmentModel();
        $product->rackno = $_POST['rackno'];
        return $product ->warehouseitem();
    }
    
    function viewdisplay() {
        $product = new adjustmentModel();
        return $product ->viewdisplay();
    }
    
    function getdisplayitem() {
        $product = new adjustmentModel();
        $product->norack = $_POST['norack'];
        return $product ->displayitem();
    }
    
    function Waudit(){
        $product = new adjustmentModel();
        $number = sizeof($_POST['prodid']);
        for($i=0;$i<$number;$i++){
        $product ->prodcode = $_POST['prodid'][$i];
        $product ->qty = $_POST['counted'][$i];   
        $product->addWaudit();}
        
            $message = "Successfully Saved!";
    		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/supervisor/audited.php';</script>";
    }
    
    function Daudit(){
        $product = new adjustmentModel();
        $number = sizeof($_POST['prod']);
        for($i=0;$i<$number;$i++){
        $product ->display = $_POST['disp'][$i];
        $product ->prod = $_POST['prod'][$i];
        $product ->count = $_POST['count'][$i];   
        $product->addDaudit();}
        
            $message = "Successfully Saved!";
    		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/supervisor/audited.php';</script>";
    }
    
    function viewcountedW(){
        $product = new adjustmentModel();
        return $product ->viewWcounted();
    }
    
    function viewcountedD(){
        $product = new adjustmentModel();
        return $product ->viewDcounted();
    }
    
    function viewoverall(){
        $product = new adjustmentModel();
        return $product ->viewoverallaudit();
    }
    
    function auditt(){
        $product = new adjustmentModel();
        $number = sizeof($_POST['prodcode']);
        for($i=0;$i<$number;$i++){
        $product ->prodcode = $_POST['prodcode'][$i];
        $product ->prodname = $_POST['prodname'][$i];
        $product ->Wqty = $_POST['Wqty'][$i];
        $product ->Wsqty = $_POST['Wsqty'][$i];
        $product ->Dqty = $_POST['Dqty'][$i];
        $product ->Dsqty = $_POST['Dsqty'][$i];
        $product ->Ocqty = $_POST['Ocqty'][$i];
        $product ->Oscqty = $_POST['Osqty'][$i];
        $product ->differ = $_POST['differ'][$i];
        $product ->loss = $_POST['loss'][$i];
        $product ->AuditRef = $_POST['auditname'];
        $product ->Date = date('Y/m/d'); 
        
        $product->addtoaudit();}
        
            $message = "Successfully Saved!";
    		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/supervisor/auditlist.php';</script>";
    }
    
    function viewaudit(){
        $product = new adjustmentModel();
        return $product->viewauditlist();
    }
    
    function audititem($viewaudit){
        $product = new adjustmentModel();
        $product->refer = $viewaudit;
        return $product->audititemlist();
    }

}

?>