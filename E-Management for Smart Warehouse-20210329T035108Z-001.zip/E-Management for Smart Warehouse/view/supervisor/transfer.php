<?php
include 'header.php';
require_once '../../controller/supervisor/productController.php';

$product = new productController();
$data = $product -> viewtrans();

?>

<section id="main-content">
  <section class="wrapper">

    <div class="row">
      <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
            <li><i class="icon_documents"></i><a href="adjustment.php">Adjustment</a></li>
          <li><i class="fa fa-arrow-down"></i>Transfer</li>
        </ol>
      </div>
    </div>
         <div class="row">
      <div class="col-sm-6">
        <section class="panel">
          <header class="panel-heading">
            Transfer History
          </header>

          <table class="table">
            <thead>
              <tr>
                <th>No</th>
                <th>Transfer Type</th>
                <th>Date</th>
                <th>Action</th>
              </tr>
            </thead>
            <tr>
            <?php
            $counter=1;
            foreach ($data as $value) {
                echo "<tr>"
                    . "<td>".$counter."</td>"
                    . "<td>".$value['transfername']."</td>"
                    . "<td>".$value['transferdate']."</td>";
            ?>
            <td>
                <form action="" method="POST">
                    <input type="button" class="btn btn-primary" value="View" onclick="location.href='viewtransfer.php?transfername=<?=$value['transfername']?>&transferdate=<?=$value['transferdate']?>'">&nbsp;
            </td>
            </tr>
            <?php
                 echo "</tr>";
                 $counter++;
                }
                ?>
          </table>
        </section>
          <input type="button" class="btn btn-default" onclick="location.href='adjustment.php'" value="Back">      
          </form>
      </div>
    </div>
  </section>
<!--main content end-->
</section>   

<?php
include 'footer.php';
?>