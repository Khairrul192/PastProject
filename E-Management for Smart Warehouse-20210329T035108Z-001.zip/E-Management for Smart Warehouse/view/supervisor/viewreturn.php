<?php
include 'header.php';
require_once '../../controller/supervisor/productController.php';

$product = new productController();
$data = $product -> viewreturnhistory($_GET['viewreturn']);

?>
    <!--main content start-->
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
              <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-home"></i><a href="returnlist.php">Vendor</a></li>
              <li><i class="fa fa-table"></i><a href="returnpast.php">Return History</a></li>
              <li><i class="fa fa-th-list"></i>Return List</li>
            </ol>
          </div>
        </div>
        <!-- order table start-->
        <div class="row">
          <div class="col-lg-10">
            <section class="panel">
              <header class="panel-heading">
                Product List
              </header>
              <div class="table-responsive">
                <table class="table">
                  <thead>
                      <th>No</th>
                      <th>Product Code</th>
                      <th>Product Name</th>
                      <th>Retail Price</th>
                      <th>Quantity</th>
                      <th>Total Loss</th>
                  </thead>
                      <?php
                    $counter=1;
                    foreach($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"
                        . "<td>".$row['ProdCode']."</td>"
                        . "<td>".$row['ProdName']."</td>"
                        . "<td>RM ".$row['ProdPrice']."</td>"
                        . "<td>".$row['rerptqty']."</td>"
                        . "<td>RM ".((int)$row['rerptqty']*(float)$row['ProdPrice'])."</td>"
                        ?>
                  <?php
                     echo "</tr>";
                     $counter++;
                    }
                    ?>
                </table>                  
              </div>
            </section>
      <form action="" method="POST">
      <input type="button" class="btn btn-success" value="Print">&nbsp;
      <input type="button" class="btn btn-default" onclick="location.href='returnpast.php'" value="Back">       
      </form>
          </div>
        </div>
        <!-- order table end-->
      </section>
    </section>          

<?php
include 'footer.php';
?>