<?php
include 'header.php';
require_once '../../controller/supervisor/adjustmentController.php';


?>


<section id="main-content">
  <section class="wrapper">

    <div class="row">
      <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
            <li><i class="icon_document"></i><a href="auditlist.php">Audit</a></li>
          <li><i class="icon_documents"></i>Create Audit</li>
        </ol>
          <form  class="form-horizontal" action="" method="POST">
         <div class="form-group">
            <label class="control-label col-lg-1">Location</label>
            <div class="col-sm-2">
                <select class="form-control" id="itemcode" name="itemcode">
                                <option disabled selected value>Select Location</option>
                                <option value="warehouse">Warehouse</option>
                                <option value="display">Display</option>
                            </select>
            </div>
            <label class="control-label col-lg-1">Rack No</label>
            <div class="col-sm-2">
                <select class="form-control" id="rackno" name="rackno" onchange="form.submit()">
                                <option disabled selected value>Select Rack</option>
                            </select>
            </div>            
          </div>
          </form>
      </div>
    </div><br>
      <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                <i class="fa fa-bookmark"></i>Audit report
              </header>
              <div class="panel-body">

                  <!--table report-->
                  <table class="table table-striped table-advance table-hover">
            <thead>
              <tr>
                <th>Shelf</th>
                <th>Code</th>
                <th>Name</th>
                <th>Counted Qty</th>
                <th>System Qty</th>
                <th>Difference</th>
                <th>Counted Amount</th>
                <th>System Amount</th>
                <th>Difference Amount</th>
              </tr> 
            </thead>               
                <tr>
                <td></td>
                <td></td>
                <td></td>
                <td><input class="form-control" name="counted" type="number"  required /></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            </tr>
          </table>

              </div>

            </section>
              <p align="right"><input class="btn btn-info" align="right" type="submit" name="add" value="Save"></p>
          </div>
      </div>


  </section>
</section>                  
<script language="JavaScript" type="text/javascript" src="jquery-1.11.1.min.js"></script>
<script>
function select_cir(id) {
    $.ajax({
                    type : "POST",
                    data : {id:id},
                    url : "process.php",
                    success : function (res2) {
                            //alert(res2);
                            $('#rackno').append(res2);
                    },
                    error:function (res2){
                            alert("error");}
            });
}

$(document).ready(function(e) {
$("#itemcode").on("change",function() {
    var id = document.getElementById("itemcode").value;

    document.getElementById("rackno").options.length=0;

    select_cir(id);
});  
});


</script>
<?php
include 'footer.php';
?>

