-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 25, 2020 at 06:01 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ispsm`
--

-- --------------------------------------------------------

--
-- Table structure for table `aaudit`
--

CREATE TABLE `aaudit` (
  `aauditid` int(11) NOT NULL,
  `disqty` int(11) NOT NULL,
  `ProdId` int(11) NOT NULL,
  `DispId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminId` int(11) NOT NULL,
  `adminUsername` varchar(50) NOT NULL,
  `adminPass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminId`, `adminUsername`, `adminPass`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `audit`
--

CREATE TABLE `audit` (
  `AuditIW` int(11) NOT NULL,
  `wareqty` int(11) NOT NULL,
  `ProdId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `auditrpt`
--

CREATE TABLE `auditrpt` (
  `auditrptid` int(11) NOT NULL,
  `auditname` varchar(250) NOT NULL,
  `Date` date NOT NULL,
  `prodcode` varchar(100) NOT NULL,
  `prodname` varchar(250) NOT NULL,
  `Wqty` varchar(1100) NOT NULL,
  `Dqty` varchar(110) NOT NULL,
  `Wsqty` varchar(110) NOT NULL,
  `Dsqty` varchar(110) NOT NULL,
  `Ocqty` varchar(110) NOT NULL,
  `Osqty` varchar(110) NOT NULL,
  `differ` varchar(110) NOT NULL,
  `loss` varchar(110) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auditrpt`
--

INSERT INTO `auditrpt` (`auditrptid`, `auditname`, `Date`, `prodcode`, `prodname`, `Wqty`, `Dqty`, `Wsqty`, `Dsqty`, `Ocqty`, `Osqty`, `differ`, `loss`) VALUES
(22, 'May Audit', '2020-05-09', '1568569854', '100plus original 1500ml', '3', '1', '3', '1', '4', '4', '0', '0'),
(23, 'May Audit', '2020-05-09', '1568569855', '100plus original 500ml', '11', '1', '11', '1', '12', '12', '0', '0'),
(24, 'May Audit', '2020-05-09', '1568569885', '100plus Strawberry 500ml', '32', '1', '32', '1', '33', '33', '0', '0'),
(25, 'May Audit', '2020-05-09', '1568569888', '100plus Lime 500ml', '13', '1', '13', '1', '14', '14', '0', '0'),
(26, 'May Audit', '2020-05-09', '1536986541', 'Cadbury Dairy Milk Roast Almond 100g', '25', '25', '25', '25', '50', '50', '0', '0'),
(27, 'May Audit', '2020-05-09', '1536986542', 'Cadbury Dairy Milk Oreo 100g', '25', '25', '25', '25', '50', '50', '0', '0'),
(28, 'May Audit', '2020-05-09', '1536986547', 'Cadbury Dairy Milk Chocolate 100g', '25', '10', '25', '25', '35', '50', '-15', '-66.75'),
(29, 'May Audit', '2020-05-09', '1536986548', 'Cadbury Dairy Milk Fruit & Nut 100g', '25', '13', '25', '25', '38', '50', '-12', '-53.4'),
(30, 'May Audit', '2020-05-09', '1568536666', 'Gardenia Original Classic 600g', '28', '5', '40', '5', '33', '45', '-12', '-34.2'),
(31, 'May Audit', '2020-05-09', '2147483647', 'Gardenia Bonanza 600g', '40', '3', '72', '3', '43', '75', '-32', '-116.8'),
(32, 'July Audit', '2020-07-21', '3201478', 'Mega Fresh Tempura Chicken Nugget 850g', '20', '15', '20', '15', '35', '35', '0', '0'),
(33, 'July Audit', '2020-07-21', '36214021', 'Mega Fresh Mixed Vegetable 400g', '20', '15', '20', '15', '35', '35', '0', '0'),
(34, 'July Audit', '2020-07-21', '36524785', 'Ramly Burger Ayam', '30', '15', '15', '25', '45', '40', '5', '27.5'),
(35, 'July Audit', '2020-07-21', '62398714', 'Ramly Burger Ayam Rasa Panggang', '30', '15', '30', '15', '45', '45', '0', '0'),
(36, 'July Audit', '2020-07-21', '74582147', 'Ramly Burger Lembu  Rasa Panggang', '30', '15', '30', '15', '45', '45', '0', '0'),
(37, 'July Audit', '2020-07-21', '74847514', 'Ramly Nuget Ayam 1KG', '30', '15', '30', '15', '45', '45', '0', '0'),
(38, 'July Audit', '2020-07-21', '78569632', 'Ramly Burger Lembu ', '30', '15', '30', '15', '45', '45', '0', '0'),
(39, 'July Audit', '2020-07-21', '95135726', 'Ramly Nuget Lembu 1KG', '30', '15', '30', '15', '45', '45', '0', '0'),
(40, 'July Audit', '2020-07-21', '47412740', 'F&N Smashing Strawberry 325ml', '240', '15', '240', '15', '255', '255', '0', '0'),
(41, 'July Audit', '2020-07-21', '96370934', 'F&N Groovy Grape 325ml', '240', '15', '340', '15', '255', '355', '-100', '-150'),
(42, 'July Audit', '2020-07-21', '575727171', 'F&N Outrageous Orange 325ml', '238', '15', '218', '15', '253', '233', '20', '30'),
(43, 'July Audit', '2020-07-21', '1021545744', 'F&N Ginger Ade 325ml', '240', '15', '240', '15', '255', '255', '0', '0'),
(44, 'July Audit', '2020-07-21', '1568569854', '100plus original 1500ml', '210', '30', '210', '30', '240', '240', '0', '0'),
(45, 'July Audit', '2020-07-21', '1568569855', '100plus original 500ml', '210', '30', '210', '30', '240', '240', '0', '0'),
(46, 'July Audit', '2020-07-21', '1568569885', '100plus Strawberry 500ml', '205', '30', '205', '30', '235', '235', '0', '0'),
(47, 'July Audit', '2020-07-21', '1568569888', '100plus Lime 500ml', '210', '30', '210', '30', '240', '240', '0', '0'),
(48, 'July Audit', '2020-07-21', '6789410', 'Goodday UHT Milk 1L - Full Cream', '30', '15', '30', '15', '45', '45', '0', '0'),
(49, 'July Audit', '2020-07-21', '9517520', 'Goodday Milk Chocolate 1L', '30', '15', '30', '15', '45', '45', '0', '0'),
(50, 'July Audit', '2020-07-21', '9638520', 'Goodday Milk Strawberry 1L', '30', '15', '30', '15', '45', '45', '0', '0'),
(51, 'July Audit', '2020-07-21', '75208410', 'Goodday Fresh Milk 1L', '30', '15', '30', '15', '45', '45', '0', '0'),
(52, 'July Audit', '2020-07-21', '32145678', 'Spritzer Natural Mineral Water 6L', '30', '15', '30', '15', '45', '45', '0', '0'),
(53, 'July Audit', '2020-07-21', '96321567', 'Spritzer Natural Mineral Water 600ml x 24', '30', '15', '30', '15', '45', '45', '0', '0'),
(54, 'July Audit', '2020-07-21', '98745678', 'Spritzer Natural Mineral Water 1500ml', '30', '15', '30', '15', '45', '45', '0', '0'),
(55, 'July Audit', '2020-07-21', '123457410', 'Spritzer Natural Mineral Water 9.5L', '30', '15', '30', '15', '45', '45', '0', '0'),
(56, 'July Audit', '2020-07-21', '10000364', 'Twiggies Cream Dream', '20', '15', '20', '15', '35', '35', '0', '0'),
(57, 'July Audit', '2020-07-21', '23640021', 'Twiggies Tiramisu', '20', '15', '20', '15', '35', '35', '0', '0'),
(58, 'July Audit', '2020-07-21', '135697556', 'Gardenia Bran & Wheat Germ 400g', '20', '15', '20', '15', '35', '35', '0', '0'),
(59, 'July Audit', '2020-07-21', '315456354', 'Gardenia Bonanza 600g', '38', '15', '38', '15', '53', '53', '0', '0'),
(60, 'July Audit', '2020-07-21', '359432546', 'Squiggles Choco Malto', '20', '15', '20', '15', '35', '35', '0', '0'),
(61, 'July Audit', '2020-07-21', '846235674', 'Gardenia Whole Wheat 600g', '20', '15', '20', '15', '35', '35', '0', '0'),
(62, 'July Audit', '2020-07-21', '963753014', 'Gardenia Canadian Purple Wheat 400g', '20', '15', '20', '15', '35', '35', '0', '0'),
(63, 'July Audit', '2020-07-21', '1000325477', 'Twiggies Choc-a-lot ', '20', '15', '20', '15', '35', '35', '0', '0'),
(64, 'July Audit', '2020-07-21', '1568536666', 'Gardenia Original Classic 600g', '20', '15', '20', '15', '35', '35', '0', '0'),
(65, 'July Audit', '2020-07-21', '2136256232', 'Squiggles Funky Strawberry', '20', '15', '20', '15', '35', '35', '0', '0'),
(66, 'July Audit', '2020-07-21', '123658', 'Whole Round Baby Squid 1KG', '15', '15', '15', '15', '30', '30', '0', '0'),
(67, 'July Audit', '2020-07-21', '756932', 'Whole Round Cuttlefish', '15', '15', '15', '15', '30', '30', '0', '0'),
(68, 'July Audit', '2020-07-21', '963879', 'Whole Round Leather Jacket 1KG', '15', '15', '15', '15', '30', '30', '0', '0'),
(69, 'July Audit', '2020-07-21', '968535', 'Whole Round Squid 1KG', '15', '15', '15', '15', '30', '30', '0', '0'),
(70, 'July Audit', '2020-07-21', '8523654', 'Whole Round Ribbonfish 1KG', '15', '15', '15', '15', '30', '30', '0', '0'),
(71, 'July Audit', '2020-07-21', '32657851', 'Munchys Lexus Sandwich Peanut (19g x 10\'s)', '30', '15', '30', '15', '45', '45', '0', '0'),
(72, 'July Audit', '2020-07-21', '32657851', 'Munchys Lexus Sandwich Peanut (19g x 10\'s)', '30', '15', '30', '15', '45', '45', '0', '0'),
(73, 'July Audit', '2020-07-21', '74136587', 'Chipsmore Biscuit Double Choc Chocolate 32g', '30', '15', '30', '15', '45', '45', '0', '0'),
(74, 'July Audit', '2020-07-21', '74136587', 'Chipsmore Biscuit Double Choc Chocolate 32g', '30', '15', '30', '15', '45', '45', '0', '0'),
(75, 'July Audit', '2020-07-21', '84651348', 'Chipsmore Original Chocolate Chip Cookies 163g', '30', '15', '30', '15', '45', '45', '0', '0'),
(76, 'July Audit', '2020-07-21', '84651348', 'Chipsmore Original Chocolate Chip Cookies 163g', '30', '15', '30', '15', '45', '45', '0', '0'),
(77, 'July Audit', '2020-07-21', '98753147', 'Chipsmore Double Choc Chocolate Chip Cookies 163g', '30', '15', '30', '15', '45', '45', '0', '0'),
(78, 'July Audit', '2020-07-21', '98753147', 'Chipsmore Double Choc Chocolate Chip Cookies 163g', '30', '15', '30', '15', '45', '45', '0', '0'),
(79, 'July Audit', '2020-07-21', '741056789', 'Munchys Lexus Sandwich (19g x 10\'s) - Cheese', '30', '15', '30', '15', '45', '45', '0', '0'),
(80, 'July Audit', '2020-07-21', '741056789', 'Munchys Lexus Sandwich (19g x 10\'s) - Cheese', '30', '15', '30', '15', '45', '45', '0', '0'),
(81, 'July Audit', '2020-07-21', '935725438', 'Chipsmore Biscuit Original 32g', '30', '15', '30', '15', '45', '45', '0', '0'),
(82, 'July Audit', '2020-07-21', '935725438', 'Chipsmore Biscuit Original 32g', '30', '15', '30', '15', '45', '45', '0', '0'),
(83, 'July Audit', '2020-07-21', '3246612', 'Nestlé Koko Krunch 330g', '30', '15', '30', '15', '45', '45', '0', '0'),
(84, 'July Audit', '2020-07-21', '45757571', 'Nestlé Corn Flakes 275g', '30', '15', '30', '15', '45', '45', '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `categoryID` int(11) NOT NULL,
  `categoryName` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryID`, `categoryName`) VALUES
(36, 'Fresh Foods'),
(37, 'Grocery'),
(38, 'Baby'),
(39, 'Chilled and Frozen'),
(40, 'Drinks'),
(41, 'Health and Beauty'),
(42, 'Household'),
(43, 'Pets'),
(44, 'Non-Food and Gifting'),
(45, 'Food');

-- --------------------------------------------------------

--
-- Table structure for table `clerk`
--

CREATE TABLE `clerk` (
  `ClerkId` int(15) NOT NULL,
  `ClerkPwd` int(15) NOT NULL,
  `ClerkName` varchar(100) NOT NULL,
  `ClerkEmail` varchar(50) NOT NULL,
  `ClerkPNo` int(12) NOT NULL,
  `ClerkAdd` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clerk`
--

INSERT INTO `clerk` (`ClerkId`, `ClerkPwd`, `ClerkName`, `ClerkEmail`, `ClerkPNo`, `ClerkAdd`) VALUES
(123456, 123456, 'Khairul Ikhwan bin Ahmad Zaini', 'khairulikhwan192@gmail.com', 172864590, 'No 5, jalan sejahtera 20, Taman Desa Skudai');

-- --------------------------------------------------------

--
-- Table structure for table `display`
--

CREATE TABLE `display` (
  `DispId` int(11) NOT NULL,
  `RackId` int(11) NOT NULL,
  `Dqty` int(11) NOT NULL,
  `ProdId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `display`
--

INSERT INTO `display` (`DispId`, `RackId`, `Dqty`, `ProdId`) VALUES
(11, 7, 15, 31),
(12, 7, 15, 32),
(13, 4, 15, 5),
(14, 4, 15, 6),
(15, 7, 15, 30),
(16, 7, 25, 33),
(17, 8, 30, 1),
(18, 8, 30, 2),
(19, 8, 30, 3),
(21, 8, 30, 4),
(22, 31, 15, 34),
(23, 31, 15, 35),
(24, 31, 15, 36),
(25, 31, 15, 37),
(26, 31, 15, 38),
(27, 4, 15, 39),
(28, 4, 15, 40),
(29, 4, 15, 41),
(30, 4, 15, 42),
(31, 4, 15, 43),
(32, 4, 15, 44),
(33, 4, 15, 45),
(34, 4, 15, 46),
(35, 39, 15, 54),
(36, 39, 15, 55),
(37, 39, 15, 56),
(38, 39, 15, 57),
(39, 39, 15, 90),
(40, 39, 15, 91),
(41, 41, 15, 69),
(42, 41, 15, 70),
(43, 41, 15, 71),
(45, 41, 15, 72),
(46, 32, 15, 92),
(47, 32, 15, 93),
(48, 32, 15, 94),
(50, 32, 15, 95),
(51, 32, 15, 96),
(52, 42, 15, 78),
(53, 42, 15, 79),
(54, 42, 15, 80),
(55, 42, 15, 81),
(56, 47, 15, 65),
(57, 47, 15, 66),
(58, 47, 15, 67),
(59, 47, 15, 68),
(60, 62, 25, 47),
(61, 62, 15, 48),
(62, 62, 15, 49),
(63, 62, 15, 50),
(64, 62, 15, 51),
(65, 62, 15, 52),
(66, 62, 15, 99),
(67, 62, 15, 100),
(68, 8, 15, 60),
(69, 8, 15, 61),
(70, 8, 15, 63),
(71, 8, 15, 62),
(72, 56, 15, 82),
(73, 56, 15, 83),
(74, 56, 15, 84),
(75, 56, 15, 85),
(76, 65, 15, 86),
(77, 65, 15, 87),
(78, 65, 15, 88),
(79, 65, 15, 89),
(80, 54, 15, 73),
(81, 54, 15, 74),
(82, 54, 15, 76),
(83, 54, 15, 75),
(84, 54, 15, 77),
(85, 66, 15, 97),
(86, 66, 15, 98);

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `invId` int(11) NOT NULL,
  `RefNo` varchar(50) NOT NULL,
  `receipt` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  `Invqty` int(11) NOT NULL,
  `ordqty` int(11) NOT NULL,
  `ProdId` int(11) NOT NULL,
  `RegNo` varchar(250) NOT NULL,
  `remark` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `invoice`
--

INSERT INTO `invoice` (`invId`, `RefNo`, `receipt`, `Date`, `Invqty`, `ordqty`, `ProdId`, `RegNo`, `remark`) VALUES
(21, 'FN9532154', '7564', '2020-07-21', 240, 240, 60, '0004594A', 'Correct Order'),
(22, 'FN9532154', '7564', '2020-07-21', 240, 240, 61, '0004594A', 'Correct Order'),
(23, 'FN9532154', '7564', '2020-07-21', 238, 238, 62, '0004594A', 'Correct Order'),
(24, 'FN9532154', '7564', '2020-07-21', 240, 240, 63, '0004594A', 'Correct Order'),
(25, 'WU1236895', '8546', '2020-07-21', 20, 20, 73, '0051554K', 'Correct Order'),
(26, 'WU1236895', '8546', '2020-07-21', 20, 20, 74, '0051554K', 'Correct Order'),
(27, 'WU1236895', '8546', '2020-07-21', 20, 20, 75, '0051554K', 'Correct Order'),
(28, 'WU1236895', '8546', '2020-07-21', 20, 20, 76, '0051554K', 'Correct Order'),
(29, 'WU1236895', '8546', '2020-07-21', 20, 20, 77, '0051554K', 'Correct Order'),
(30, 'OCF39743', '6497', '2020-07-21', 15, 15, 34, '0569436W', 'Correct Order'),
(31, 'OCF39743', '6497', '2020-07-21', 15, 15, 35, '0569436W', 'Correct Order'),
(32, 'OCF39743', '6497', '2020-07-21', 15, 15, 36, '0569436W', 'Correct Order'),
(33, 'OCF39743', '6497', '2020-07-21', 15, 15, 37, '0569436W', 'Correct Order'),
(34, 'OCF39743', '6497', '2020-07-21', 15, 15, 38, '0569436W', 'Correct Order'),
(35, 'RC4532356', '1908', '2020-07-21', 20, 20, 97, '175141-H', 'Correct Order'),
(36, 'RC4532356', '1908', '2020-07-21', 20, 20, 98, '175141-H', 'Correct Order'),
(37, 'RM953244', '4786', '2020-07-21', 30, 30, 47, '0265231T', 'Correct Order'),
(38, 'RM953244', '4786', '2020-07-21', 30, 30, 48, '0265231T', 'Correct Order'),
(39, 'RM953244', '4786', '2020-07-21', 30, 30, 49, '0265231T', 'Correct Order'),
(40, 'RM953244', '4786', '2020-07-21', 30, 30, 50, '0265231T', 'Correct Order'),
(41, 'RM953244', '4786', '2020-07-21', 30, 30, 51, '0265231T', 'Correct Order'),
(42, 'RM953244', '4786', '2020-07-21', 30, 30, 52, '0265231T', 'Correct Order'),
(43, 'AR973521', '7237', '2020-06-10', 30, 30, 92, '1305833-M', 'Correct Order'),
(44, 'AR973521', '7237', '2020-06-10', 30, 30, 93, '1305833-M', 'Correct Order'),
(45, 'AR973521', '7237', '2020-06-10', 30, 30, 94, '1305833-M', 'Correct Order'),
(46, 'AR973521', '7237', '2020-06-10', 30, 30, 95, '1305833-M', 'Correct Order'),
(47, 'AR973521', '7237', '2020-06-10', 30, 30, 96, '1305833-M', 'Correct Order'),
(48, 'MF97234', '7598', '2020-07-21', 20, 20, 99, '467565-H', 'Correct Order'),
(49, 'MF97234', '7598', '2020-07-21', 20, 20, 100, '467565-H', 'Correct Order'),
(50, 'GD9865', '7768', '2020-07-21', 20, 20, 39, '0139386X', 'Correct Order'),
(51, 'GD9865', '7768', '2020-07-21', 20, 20, 40, '0139386X', 'Correct Order'),
(52, 'GD9865', '7768', '2020-07-21', 20, 20, 41, '0139386X', 'Correct Order'),
(53, 'GD9865', '7768', '2020-07-21', 20, 20, 42, '0139386X', 'Correct Order'),
(54, 'GD9865', '7768', '2020-07-21', 20, 20, 43, '0139386X', 'Correct Order'),
(55, 'GD9865', '7768', '2020-07-21', 20, 20, 44, '0139386X', 'Correct Order'),
(56, 'GD9865', '7768', '2020-07-21', 20, 20, 45, '0139386X', 'Correct Order'),
(57, 'GD9865', '7768', '2020-07-21', 20, 20, 46, '0139386X', 'Correct Order'),
(58, 'N961475', '7440', '2020-07-21', 30, 30, 69, '0045229H', 'Correct Order'),
(59, 'N961475', '7440', '2020-07-21', 30, 30, 70, '0045229H', 'Correct Order'),
(60, 'N961475', '7440', '2020-07-21', 30, 30, 71, '0045229H', 'Correct Order'),
(61, 'N961475', '7440', '2020-07-21', 30, 30, 72, '0045229H', 'Correct Order'),
(62, 'MZ98765', '4855', '2020-07-21', 30, 30, 54, '0536551W', 'Correct Order'),
(63, 'MZ98765', '4855', '2020-07-21', 30, 30, 55, '0536551W', 'Correct Order'),
(64, 'MZ98765', '4855', '2020-07-21', 30, 30, 56, '0536551W', 'Correct Order'),
(65, 'MZ98765', '4855', '2020-07-21', 30, 30, 57, '0536551W', 'Correct Order'),
(66, 'MCH987532145', '8784', '2020-07-21', 30, 30, 90, '220353-H', 'Correct Order'),
(67, 'MCH987532145', '8784', '2020-07-21', 30, 30, 91, '220353-H', 'Correct Order'),
(68, 'N961476', '4095', '2020-07-21', 50, 50, 65, '0045229H', 'Correct Order'),
(69, 'N961476', '4095', '2020-07-21', 50, 50, 66, '0045229H', 'Correct Order'),
(70, 'N961476', '4095', '2020-07-21', 50, 50, 67, '0045229H', 'Correct Order'),
(71, 'N961476', '4095', '2020-07-21', 50, 50, 68, '0045229H', 'Correct Order'),
(72, 'JL973541', '6310', '2020-06-20', 30, 30, 78, '0180398P', 'Correct Order'),
(73, 'JL973541', '6310', '2020-06-20', 30, 30, 79, '0180398P', 'Correct Order'),
(74, 'JL973541', '6310', '2020-06-20', 30, 30, 80, '0180398P', 'Correct Order'),
(75, 'JL973541', '6310', '2020-06-20', 30, 30, 81, '0180398P', 'Correct Order'),
(76, 'SP7430102', '9147', '2020-07-21', 30, 30, 86, '1304862-H', 'Correct Order'),
(77, 'SP7430102', '9147', '2020-07-21', 30, 30, 87, '1304862-H', 'Correct Order'),
(78, 'SP7430102', '9147', '2020-07-21', 30, 30, 88, '1304862-H', 'Correct Order'),
(79, 'SP7430102', '9147', '2020-07-21', 30, 30, 89, '1304862-H', 'Correct Order'),
(80, 'EF96312587', '1405', '2020-07-21', 30, 30, 82, '127844D', 'Correct Order'),
(81, 'EF96312587', '1405', '2020-07-21', 30, 30, 83, '127844D', 'Correct Order'),
(82, 'EF96312587', '1405', '2020-07-21', 30, 30, 84, '127844D', 'Correct Order'),
(83, 'EF96312587', '1405', '2020-07-21', 30, 30, 85, '127844D', 'Correct Order'),
(84, 'FN22720', '1359', '2020-07-21', 100, 100, 60, '0004594A', 'Correct Order');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `NotyId` int(11) NOT NULL,
  `NotyMsg` text NOT NULL,
  `NotyDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ord`
--

CREATE TABLE `ord` (
  `OrdId` int(11) NOT NULL,
  `ProdId` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `RegNo` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ordcart`
--

CREATE TABLE `ordcart` (
  `cartid` int(11) NOT NULL,
  `ProdId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ordrpt`
--

CREATE TABLE `ordrpt` (
  `ordrptid` int(11) NOT NULL,
  `Ordno` int(11) NOT NULL,
  `date` date NOT NULL,
  `ProdId` int(11) NOT NULL,
  `RegNo` varchar(250) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ordrpt`
--

INSERT INTO `ordrpt` (`ordrptid`, `Ordno`, `date`, `ProdId`, `RegNo`, `qty`) VALUES
(15, 1600639986, '2020-07-21', 60, '0004594A', 240),
(16, 1600639986, '2020-07-21', 61, '0004594A', 240),
(17, 1600639986, '2020-07-21', 62, '0004594A', 238),
(18, 1600639986, '2020-07-21', 63, '0004594A', 240),
(19, 190549757, '2020-07-21', 73, '0051554K', 20),
(20, 190549757, '2020-07-21', 74, '0051554K', 20),
(21, 190549757, '2020-07-21', 75, '0051554K', 20),
(22, 190549757, '2020-07-21', 76, '0051554K', 20),
(23, 190549757, '2020-07-21', 77, '0051554K', 20),
(24, 1919196088, '2020-06-21', 34, '0569436W', 15),
(25, 1919196088, '2020-06-21', 35, '0569436W', 15),
(26, 1919196088, '2020-06-21', 36, '0569436W', 15),
(27, 1919196088, '2020-06-21', 37, '0569436W', 15),
(28, 1919196088, '2020-06-21', 38, '0569436W', 15),
(29, 736041131, '2020-07-21', 97, '175141-H', 20),
(30, 736041131, '2020-07-21', 98, '175141-H', 20),
(31, 1355282173, '2020-07-21', 39, '0139386X', 20),
(32, 1355282173, '2020-07-21', 40, '0139386X', 20),
(33, 1355282173, '2020-07-21', 41, '0139386X', 20),
(34, 1355282173, '2020-07-21', 42, '0139386X', 20),
(35, 1355282173, '2020-07-21', 43, '0139386X', 20),
(36, 1355282173, '2020-07-21', 44, '0139386X', 20),
(37, 1355282173, '2020-07-21', 45, '0139386X', 20),
(38, 1355282173, '2020-07-21', 46, '0139386X', 20),
(39, 927526932, '2020-07-21', 47, '0265231T', 30),
(40, 927526932, '2020-07-21', 48, '0265231T', 30),
(41, 927526932, '2020-07-21', 49, '0265231T', 30),
(42, 927526932, '2020-07-21', 50, '0265231T', 30),
(43, 927526932, '2020-07-21', 51, '0265231T', 30),
(44, 927526932, '2020-07-21', 52, '0265231T', 30),
(45, 10449340, '2020-05-21', 92, '1305833-M', 30),
(46, 10449340, '2020-05-21', 93, '1305833-M', 30),
(47, 10449340, '2020-05-21', 94, '1305833-M', 30),
(48, 10449340, '2020-05-21', 95, '1305833-M', 30),
(49, 10449340, '2020-05-21', 96, '1305833-M', 30),
(50, 1805819696, '2020-05-21', 99, '467565-H', 20),
(51, 1805819696, '2020-05-21', 100, '467565-H', 20),
(52, 571103633, '2020-07-21', 69, '0045229H', 30),
(53, 571103633, '2020-07-21', 70, '0045229H', 30),
(54, 571103633, '2020-07-21', 71, '0045229H', 30),
(55, 571103633, '2020-07-21', 72, '0045229H', 30),
(56, 716084209, '2020-07-21', 54, '0536551W', 30),
(57, 716084209, '2020-07-21', 55, '0536551W', 30),
(58, 716084209, '2020-07-21', 56, '0536551W', 30),
(59, 716084209, '2020-07-21', 57, '0536551W', 30),
(60, 66649691, '2020-07-21', 90, '220353-H', 30),
(61, 66649691, '2020-07-21', 91, '220353-H', 30),
(62, 1276553805, '2020-07-21', 65, '0045229H', 50),
(63, 1276553805, '2020-07-21', 66, '0045229H', 50),
(64, 1276553805, '2020-07-21', 67, '0045229H', 50),
(65, 1276553805, '2020-07-21', 68, '0045229H', 50),
(66, 1745958337, '2020-06-15', 78, '0180398P', 30),
(67, 1745958337, '2020-06-15', 79, '0180398P', 30),
(68, 1745958337, '2020-06-15', 80, '0180398P', 30),
(69, 1745958337, '2020-06-15', 81, '0180398P', 30),
(70, 1897454108, '2020-07-10', 82, '127844D', 30),
(71, 1897454108, '2020-07-10', 83, '127844D', 30),
(72, 1897454108, '2020-07-10', 84, '127844D', 30),
(73, 1897454108, '2020-07-10', 85, '127844D', 30),
(74, 1474662366, '2020-07-21', 86, '1304862-H', 30),
(75, 1474662366, '2020-07-21', 87, '1304862-H', 30),
(76, 1474662366, '2020-07-21', 88, '1304862-H', 30),
(77, 1474662366, '2020-07-21', 89, '1304862-H', 30),
(78, 720224894, '2020-07-21', 60, '0004594A', 100),
(79, 538970388, '2020-07-21', 54, '0536551W', 30);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `PayId` int(11) NOT NULL,
  `invId` int(11) NOT NULL,
  `PayAmt` float NOT NULL,
  `PayDate` date NOT NULL,
  `OrdId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProdId` int(11) NOT NULL,
  `ProdCode` int(20) NOT NULL,
  `ProdName` varchar(50) NOT NULL,
  `ProdPrice` float NOT NULL,
  `RegNo` varchar(250) NOT NULL,
  `categoryID` int(11) NOT NULL,
  `SubCategoryID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProdId`, `ProdCode`, `ProdName`, `ProdPrice`, `RegNo`, `categoryID`, `SubCategoryID`) VALUES
(1, 1568569854, '100plus original 1500ml', 2.65, '0004594A', 40, 44),
(2, 1568569855, '100plus original 500ml', 2, '0004594A', 40, 44),
(3, 1568569888, '100plus Lime 500ml', 2, '0004594A', 40, 44),
(4, 1568569885, '100plus Strawberry 500ml', 2, '0004594A', 40, 44),
(5, 315456354, 'Gardenia Bonanza 600g', 3.65, '0139386X', 36, 4),
(6, 1568536666, 'Gardenia Original Classic 600g', 2.85, '0139386X', 36, 4),
(30, 1536986547, 'Cadbury Dairy Milk Chocolate 100g', 4.45, '0536551W', 37, 86),
(31, 1536986548, 'Cadbury Dairy Milk Fruit & Nut 100g', 4.45, '0536551W', 37, 86),
(32, 1536986541, 'Cadbury Dairy Milk Roast Almond 100g', 4.45, '0536551W', 37, 86),
(33, 1536986542, 'Cadbury Dairy Milk Oreo 100g', 4.45, '0536551W', 37, 86),
(34, 968535, 'Whole Round Squid 1KG', 13.9, '0569436W', 36, 8),
(35, 123658, 'Whole Round Baby Squid 1KG', 12.9, '0569436W', 36, 8),
(36, 756932, 'Whole Round Cuttlefish', 11.9, '0569436W', 36, 8),
(37, 8523654, 'Whole Round Ribbonfish 1KG', 7.9, '0569436W', 36, 8),
(38, 963879, 'Whole Round Leather Jacket 1KG', 8.9, '0569436W', 36, 8),
(39, 846235674, 'Gardenia Whole Wheat 600g', 4.5, '0139386X', 36, 4),
(40, 135697556, 'Gardenia Bran & Wheat Germ 400g', 2.9, '0139386X', 36, 4),
(41, 963753014, 'Gardenia Canadian Purple Wheat 400g', 2.9, '0139386X', 36, 4),
(42, 10000364, 'Twiggies Cream Dream', 1.6, '0139386X', 36, 4),
(43, 1000325477, 'Twiggies Choc-a-lot ', 1.6, '0139386X', 36, 4),
(44, 23640021, 'Twiggies Tiramisu', 1.6, '0139386X', 36, 4),
(45, 359432546, 'Squiggles Choco Malto', 1.05, '0139386X', 36, 4),
(46, 2136256232, 'Squiggles Funky Strawberry', 1.05, '0139386X', 36, 4),
(47, 36524785, 'Ramly Burger Ayam', 5.5, '0265231T', 39, 36),
(48, 62398714, 'Ramly Burger Ayam Rasa Panggang', 6.5, '0265231T', 39, 36),
(49, 78569632, 'Ramly Burger Lembu ', 5.5, '0265231T', 39, 36),
(50, 74582147, 'Ramly Burger Lembu  Rasa Panggang', 6.5, '0265231T', 39, 36),
(51, 74847514, 'Ramly Nuget Ayam 1KG', 12.9, '0265231T', 39, 36),
(52, 95135726, 'Ramly Nuget Lembu 1KG', 14.9, '0265231T', 39, 36),
(54, 84651348, 'Chipsmore Original Chocolate Chip Cookies 163g', 3.9, '0536551W', 37, 14),
(55, 98753147, 'Chipsmore Double Choc Chocolate Chip Cookies 163g', 3.9, '0536551W', 37, 14),
(56, 74136587, 'Chipsmore Biscuit Double Choc Chocolate 32g', 0.9, '0536551W', 37, 14),
(57, 935725438, 'Chipsmore Biscuit Original 32g', 0.9, '0536551W', 37, 14),
(58, 320056140, 'F&N Sweetened Creamer Vitaminised 1kg', 5.5, '0004594A', 40, 46),
(59, 136054702, 'F&N Sweetened Creamer 1kg', 5.3, '0004594A', 40, 46),
(60, 96370934, 'F&N Groovy Grape 325ml', 1.5, '0004594A', 40, 44),
(61, 1021545744, 'F&N Ginger Ade 325ml', 1.5, '0004594A', 40, 44),
(62, 575727171, 'F&N Outrageous Orange 325ml', 1.5, '0004594A', 40, 44),
(63, 47412740, 'F&N Smashing Strawberry 325ml', 1.5, '0004594A', 40, 44),
(64, 96374112, 'F&N Sweetened Creamer Hi Calcium 500g', 2.9, '0004594A', 40, 46),
(65, 74108520, 'Maggi Noodles Curry Flavoured 5 x 79g (395g)', 2.85, '0045229H', 37, 23),
(66, 3214525, 'Maggi Noodles Chicken Flavoured 5 x 79g (395g)', 2.85, '0045229H', 37, 23),
(67, 657300254, 'Maggi Noodles TomYum Flavoured 5 x 79g (395g)', 3, '0045229H', 37, 23),
(68, 306574103, 'Maggi Instant Noodles Asam Laksa 5 x 78g', 4.85, '0045229H', 37, 23),
(69, 987006547, 'Nestle MILO Breakfast Cereal (80g)', 2.75, '0045229H', 37, 16),
(70, 321450012, 'Nestlé Honey Stars 80g', 2.75, '0045229H', 37, 16),
(71, 3246612, 'Nestlé Koko Krunch 330g', 9.75, '0045229H', 37, 16),
(72, 45757571, 'Nestlé Corn Flakes 275g', 7.05, '0045229H', 37, 16),
(73, 101244223, 'Romano Fregrance Edt Force 100ml', 34.9, '0051554K', 41, 62),
(74, 10236547, 'Romano Fregrance Edt Unique 100ml', 34.9, '0051554K', 41, 62),
(75, 69320144, 'Romano Giovane Fragrance (100ml)', 34.9, '0051554K', 41, 62),
(76, 2405125, 'Romano Picco Fragrance (100ml)', 45, '0051554K', 41, 62),
(77, 4567234, 'Romano Prestige Eau de Toilette 100ml', 34.9, '0051554K', 41, 62),
(78, 21026544, 'Jalen Sweet Soy Sauce 325ml', 3.35, '0180398P', 37, 18),
(79, 9658745, 'Jalen Sweet Soy Sauce 650ml', 5.75, '0180398P', 37, 18),
(80, 32657541, 'Jalen Savoury Soy Sauce 325ml', 3.2, '0180398P', 37, 18),
(81, 25424541, 'Jalen Salt Soy Sauce 325ml', 3.1, '0180398P', 37, 18),
(82, 9638520, 'Goodday Milk Strawberry 1L', 8.5, '127844D', 40, 50),
(83, 9517520, 'Goodday Milk Chocolate 1L', 8.5, '127844D', 40, 50),
(84, 75208410, 'Goodday Fresh Milk 1L', 8.5, '127844D', 40, 50),
(85, 6789410, 'Goodday UHT Milk 1L - Full Cream', 9.9, '127844D', 40, 50),
(86, 96321567, 'Spritzer Natural Mineral Water 600ml x 24', 26.4, '1304862-H', 40, 53),
(87, 98745678, 'Spritzer Natural Mineral Water 1500ml', 2.4, '1304862-H', 40, 53),
(88, 32145678, 'Spritzer Natural Mineral Water 6L', 7.9, '1304862-H', 40, 53),
(89, 123457410, 'Spritzer Natural Mineral Water 9.5L', 9.9, '1304862-H', 40, 53),
(90, 741056789, 'Munchys Lexus Sandwich (19g x 10\'s) - Cheese', 4.8, '220353-H', 37, 14),
(91, 32657851, 'Munchys Lexus Sandwich Peanut (19g x 10\'s)', 4.8, '220353-H', 37, 14),
(92, 653698, 'Chicken Standard 1KG', 12.9, '1305833-M', 36, 10),
(93, 3026542, 'Breast Meat without Skin 1KG', 8.6, '1305833-M', 36, 10),
(94, 36001485, 'Chicken Bishop Nose 1KG', 9.9, '1305833-M', 36, 10),
(95, 6325982, 'Chicken Carcass 1KG', 3.5, '1305833-M', 36, 10),
(96, 32014752, 'Chicken Drumstick 1KG', 15.9, '1305833-M', 36, 10),
(97, 3052147, 'Dettol Instant Hand Sanitizer Original 200ml', 15.3, '175141-H', 41, 66),
(98, 35841003, 'Dettol 10 Anti-Bacterial Wet Wipes', 3.8, '175141-H', 41, 66),
(99, 3201478, 'Mega Fresh Tempura Chicken Nugget 850g', 10.85, '467565-H', 39, 36),
(100, 36214021, 'Mega Fresh Mixed Vegetable 400g', 2.1, '467565-H', 39, 36),
(101, 2147483647, 'Baking Soda', 3.5, '9865426-A', 37, 7);

-- --------------------------------------------------------

--
-- Table structure for table `rack`
--

CREATE TABLE `rack` (
  `RackId` int(11) NOT NULL,
  `categoryID` int(11) NOT NULL,
  `SubCategoryID` int(11) NOT NULL,
  `rackno` varchar(250) NOT NULL,
  `type` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rack`
--

INSERT INTO `rack` (`RackId`, `categoryID`, `SubCategoryID`, `rackno`, `type`) VALUES
(3, 36, 4, 'FF1', 'Warehouse'),
(4, 36, 4, 'FFB1', 'Display'),
(5, 37, 86, 'G1', 'Warehouse'),
(6, 40, 44, 'D1', 'Warehouse'),
(7, 37, 86, 'GCS1', 'Display'),
(8, 40, 44, 'DCD1', 'Display'),
(9, 36, 6, 'FF1', 'Warehouse'),
(10, 36, 8, 'FF2', 'Warehouse'),
(11, 36, 10, 'FF2', 'Warehouse'),
(12, 36, 9, 'FF1', 'Warehouse'),
(13, 36, 11, 'FF3', 'Warehouse'),
(14, 36, 12, 'FF2', 'Warehouse'),
(15, 36, 13, 'FF1', 'Warehouse'),
(16, 37, 14, 'G1', 'Warehouse'),
(17, 37, 15, 'G1', 'Warehouse'),
(18, 37, 16, 'G1', 'Warehouse'),
(19, 37, 7, 'G1', 'Warehouse'),
(20, 37, 18, 'G1', 'Warehouse'),
(21, 37, 19, 'G1', 'Warehouse'),
(22, 37, 20, 'G1', 'Warehouse'),
(23, 37, 21, 'G1', 'Warehouse'),
(24, 37, 22, 'G2', 'Warehouse'),
(25, 37, 23, 'G2', 'Warehouse'),
(26, 37, 24, 'G2', 'Warehouse'),
(27, 37, 25, 'G2', 'Warehouse'),
(28, 41, 62, 'HB1', 'Warehouse'),
(29, 36, 6, 'FFE1', 'Display'),
(31, 36, 8, 'FFFM1', 'Display'),
(32, 36, 10, 'FFFM2', 'Display'),
(33, 36, 9, 'FFF1', 'Display'),
(34, 36, 11, 'FFF2', 'Display'),
(36, 36, 12, 'FFO1', 'Display'),
(37, 36, 13, 'FFO2', 'Display'),
(38, 37, 7, 'GB1', 'Display'),
(39, 37, 14, 'GB2', 'Display'),
(40, 37, 15, 'GCF1', 'Display'),
(41, 37, 16, 'GC1', 'Display'),
(42, 37, 18, 'GCI1', 'Display'),
(43, 37, 19, 'GCI2', 'Display'),
(44, 37, 20, 'GDC1', 'Display'),
(45, 37, 21, 'GJS1', 'Display'),
(46, 37, 22, 'GOF1', 'Display'),
(47, 37, 23, 'GCN1', 'Display'),
(48, 37, 24, 'GR1', 'Display'),
(49, 37, 25, 'GSD1', 'Display'),
(50, 37, 26, 'GS1', 'Display'),
(51, 37, 27, 'GSF1', 'Display'),
(52, 37, 26, 'G1', 'Warehouse'),
(53, 37, 27, 'G2', 'Warehouse'),
(54, 41, 62, 'HBMG1', 'Display'),
(55, 40, 50, 'D4', 'Warehouse'),
(56, 40, 50, 'DDM1', 'Display'),
(59, 41, 66, 'HB1', 'Warehouse'),
(62, 39, 36, 'CFF1', 'Display'),
(63, 39, 36, 'CF1', 'Warehouse'),
(64, 40, 53, 'D2', 'Warehouse'),
(65, 40, 53, 'DW1', 'Display'),
(66, 41, 66, 'HSCT1', 'Display'),
(67, 38, 28, 'BBF1', 'Warehouse');

-- --------------------------------------------------------

--
-- Table structure for table `returnn`
--

CREATE TABLE `returnn` (
  `ReId` int(11) NOT NULL,
  `reason` text NOT NULL,
  `reqty` int(11) NOT NULL,
  `ProdId` int(11) NOT NULL,
  `RegNo` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `returnrpt`
--

CREATE TABLE `returnrpt` (
  `rerpt` int(11) NOT NULL,
  `rerefer` varchar(50) NOT NULL,
  `ProdId` int(11) NOT NULL,
  `reason` varchar(50) NOT NULL,
  `rerptqty` int(11) NOT NULL,
  `rerptdate` date NOT NULL,
  `RegNo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `returnrpt`
--

INSERT INTO `returnrpt` (`rerpt`, `rerefer`, `ProdId`, `reason`, `rerptqty`, `rerptdate`, `RegNo`) VALUES
(5, '395849584', 62, 'Damage', 20, '2020-07-21', '0004594A');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `SubCategoryID` int(11) NOT NULL,
  `SubCategoryName` text NOT NULL,
  `categoryID` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`SubCategoryID`, `SubCategoryName`, `categoryID`) VALUES
(4, 'Bakery', '36'),
(6, 'Eggs', '36'),
(7, 'Baking', '37'),
(8, 'Fish and Seafood', '36'),
(9, 'Fresh Fruits', '36'),
(10, 'Meats and Poultry', '36'),
(11, 'Vegetables', '36'),
(12, 'Noodles, Bean curd and Cooking Supplements', '36'),
(13, 'Other', '36'),
(14, 'Biscuit and Cakes', '37'),
(15, 'Canned Food', '37'),
(16, 'Cereals', '37'),
(18, 'Cooking Ingredient', '37'),
(19, 'Cooking Oil', '37'),
(20, 'Dry Condiment', '37'),
(21, 'Jam, Spreads and Honey', '37'),
(22, 'Organic Food', '37'),
(23, 'Pasta and Instant Noodles', '37'),
(24, 'Rice', '37'),
(25, 'Sauces and Dressing', '37'),
(26, 'Snacks', '37'),
(27, 'Sugar and Flour', '37'),
(28, 'Baby Food', '38'),
(29, 'Baby Toiletries', '38'),
(30, 'Diapers and Wipes', '38'),
(31, 'Milk Powder', '38'),
(32, 'Butter and Margarine', '39'),
(33, 'Cheese', '39'),
(34, 'Cream', '39'),
(35, 'Desserts', '39'),
(36, 'Frozen Food', '39'),
(37, 'Frozen Fruit', '39'),
(38, 'Ice Cream', '39'),
(39, 'Juices', '39'),
(40, 'Milk', '39'),
(41, 'Yoghurt', '39'),
(42, 'Adult Milk Powder', '40'),
(43, 'Asian Drinks', '40'),
(44, 'Carbonated Drinks', '40'),
(45, 'Coffee', '40'),
(46, 'Creamers', '40'),
(47, 'Flavored Beverages', '40'),
(48, 'Fruit and Vegetables Juices', '40'),
(49, 'Non-Carbonated Drinks', '40'),
(50, 'Ready to Drink Milk', '40'),
(51, 'Squash and Cordials', '40'),
(52, 'Tea', '40'),
(53, 'Water', '40'),
(54, 'Other Drinks', '40'),
(55, 'Bath Toiletries', '41'),
(56, 'Eye Care', '41'),
(57, 'Female Grooming', '41'),
(58, 'Feminine Care', '41'),
(59, 'Foot Care', '41'),
(60, 'Hair Care', '41'),
(61, 'Health Care', '41'),
(62, 'Male Grooming', '41'),
(63, 'Oral Care', '41'),
(64, 'Paper and Cotton Products', '41'),
(65, 'Skin Care and Cosmetics', '41'),
(66, 'Skin Cream and Treatment', '41'),
(67, 'Travel', '41'),
(68, 'Air Fresheners', '42'),
(69, 'Floor Cleaner', '42'),
(70, 'Household Cleaners', '42'),
(71, 'Household Sundries', '42'),
(72, 'Kitchen Cleaner', '42'),
(73, 'Laundry', '42'),
(74, 'Light Bulbs', '42'),
(75, 'Paper and Cotton Products', '42'),
(76, 'Toilet Cleaner', '42'),
(77, 'Cat Care and Accessories', '43'),
(78, 'Cat Food', '43'),
(79, 'Dog Food', '43'),
(80, 'Other Pets Food', '43'),
(81, 'Batteries', '44'),
(82, 'Cooking and Dining', '44'),
(83, 'Office, Arts and Craft', '44'),
(84, 'Party Accessories', '44'),
(85, 'Small Electrical Appliances', '44'),
(86, 'Chocolates and Sweets', '37');

-- --------------------------------------------------------

--
-- Table structure for table `supervisor`
--

CREATE TABLE `supervisor` (
  `SvId` int(15) NOT NULL,
  `SvPwd` int(15) NOT NULL,
  `SvName` varchar(100) NOT NULL,
  `SvEmail` varchar(50) NOT NULL,
  `SvPNo` int(12) NOT NULL,
  `SvAdd` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supervisor`
--

INSERT INTO `supervisor` (`SvId`, `SvPwd`, `SvName`, `SvEmail`, `SvPNo`, `SvAdd`) VALUES
(654321, 654321, 'Azizi Fahmi Bin Abd Rani', 'Azizi@gmail.com', 139638521, 'No 7, jalan mutiara rini'),
(987654, 987654, 'ikhwan khairul bin fahmi', 'ikhwan@gmail.com', 177965425, 'ump gambang');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `RegNo` varchar(50) NOT NULL,
  `SuppEmail` varchar(100) NOT NULL,
  `SuppCNo` varchar(15) NOT NULL,
  `SuppCompany` varchar(50) NOT NULL,
  `SuppDetail` varchar(500) NOT NULL,
  `SuppAccno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`RegNo`, `SuppEmail`, `SuppCNo`, `SuppCompany`, `SuppDetail`, `SuppAccno`) VALUES
('0004594A', 'FNN@fnn.com', '986547523', 'F&N Beverages Marketing Sdn Bhd.', 'Beverage and Mineral Water Provider', 236598565),
('0045229H', 'Maxine.Lim@my.nestle.com', '+60379655185', 'NESTLE PRODUCTS SDN. BHD.', 'Ice- Cream and grocery supplier', 2147483647),
('0051554K', 'enquiry@wipro-unza.com', '60356315588', 'WIPRO UNZA (M) Sdn. Bhd.', 'Halal skincare R&D facility', 2147483647),
('0139386X', 'Gardenia@gardenia.my', '975655656', 'Gardenia Bakeries  Sdn Bhd', 'Bread and Kaya Provider', 214741986),
('0180398P', 'jalensb@jalen.com.my', '607-556 7434', 'JALEN SDN. BHD.', 'Soy Sauce, Chilli Sauce, Tomato Ketchup, Oyster Flavoured Sauce, Flavoured Cordials, Artificial Vinegar, Black Pepper Sauce and Taucho.', 2147483647),
('0265231T', 'support@ramly.com.my', '+603 - 6184 297', 'Ramly Food Services Sdn. Bhd', 'Halal quality frozen products', 2147483647),
('0536551W', 'contactusmalaysia@mdlz.com', '+60378726688', 'Mondelez Malaysia', 'Snack Provider', 374565215),
('0569436W', 'teresa@oceanfresh.com', '09-534 3888', 'OCEAN FRESH SEAFOOD PRODUCTS SDN. BHD', 'Seafood products ', 2147483647),
('127844D', 'customercareline@etikaholdings.com', '07-352 5584', 'Etika Fresh Milk Manufacturing Sdn. Bhd.', 'Dairy vendor', 2147483647),
('1304862-H', 'info@spritzer.com.my', '1800883111', 'Spritzer BHD', 'Drinks Vendor', 2147483647),
('1305833-M', 'ayamevolusi@gmail.com', '016-229 3212', 'AYAM EVOLUSI SDN. BHD', 'Supply Fresh Chicken & Chicken Parts , Beef , Mutton , Lamb and more', 2147483647),
('175141-H', 'kapil.verma@rb.com', '03-7719 1000', 'Reckitt Benckiser (M) Sdn. Bhd', 'Aerosol Products, Air Fresheners, Disinfectant Sprays, Insecticide Mats', 965885742),
('220353-H', 'munchys@munchys.com.my', '+609-513 0141', 'MunchWorld Marketing Sdn. Bhd.', 'Biscuit grocery vendor', 547483647),
('467565-H', 'customercare@sccsb.com.my', '03-9058 1322', 'Mega Fresh Sdn Bhd', 'Fruit & Vegetable', 2147483647),
('766465-V', 'customercare@theitalianbaker.com.my', '1800226688', 'The Italian Baker Sdn. Bhd.', 'Bakery Vendor', 147483647),
('9865426-A', 'ABC@gmail.com', '6098563654', 'ABC SDN BHD', 'Ice - cream supply', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE `transfer` (
  `transferid` int(11) NOT NULL,
  `ProdId` int(11) NOT NULL,
  `transferqty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `transhistory`
--

CREATE TABLE `transhistory` (
  `transferid` int(11) NOT NULL,
  `transfername` varchar(250) NOT NULL,
  `transferdate` date NOT NULL,
  `ProdId` int(11) NOT NULL,
  `transferqty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transhistory`
--

INSERT INTO `transhistory` (`transferid`, `transfername`, `transferdate`, `ProdId`, `transferqty`) VALUES
(11, 'Store to display', '2020-07-10', 1, 30),
(12, 'Store to display', '2020-07-10', 2, 30),
(13, 'Store to display', '2020-07-10', 3, 30),
(14, 'Store to display', '2020-07-10', 4, 30),
(15, 'Store to display', '2020-07-21', 47, 10),
(16, 'Store to display', '2020-07-21', 33, 10);

-- --------------------------------------------------------

--
-- Table structure for table `warehouse`
--

CREATE TABLE `warehouse` (
  `warehouseId` int(11) NOT NULL,
  `ProdId` int(11) NOT NULL,
  `RackId` int(11) NOT NULL,
  `Wqty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `warehouse`
--

INSERT INTO `warehouse` (`warehouseId`, `ProdId`, `RackId`, `Wqty`) VALUES
(1, 5, 3, 38),
(2, 6, 3, 20),
(3, 30, 5, 115),
(4, 31, 5, 120),
(5, 32, 5, 120),
(6, 33, 5, 110),
(7, 1, 6, 210),
(8, 2, 6, 210),
(9, 3, 6, 210),
(10, 4, 6, 205),
(11, 34, 10, 15),
(12, 35, 10, 15),
(13, 36, 10, 15),
(14, 37, 10, 15),
(15, 38, 10, 15),
(16, 39, 3, 20),
(17, 40, 3, 20),
(18, 41, 3, 20),
(19, 42, 3, 20),
(20, 43, 3, 20),
(21, 44, 3, 20),
(22, 45, 3, 20),
(23, 46, 3, 20),
(24, 54, 16, 30),
(25, 55, 16, 30),
(27, 56, 16, 30),
(28, 57, 16, 30),
(29, 90, 16, 30),
(30, 91, 16, 30),
(31, 69, 18, 30),
(32, 70, 18, 30),
(33, 71, 18, 30),
(34, 72, 18, 30),
(36, 92, 11, 30),
(37, 93, 11, 30),
(38, 94, 11, 30),
(39, 96, 11, 30),
(40, 95, 11, 30),
(41, 78, 20, 30),
(42, 79, 20, 30),
(43, 80, 20, 30),
(44, 81, 20, 30),
(45, 65, 25, 50),
(46, 66, 25, 50),
(47, 67, 25, 50),
(48, 68, 25, 50),
(49, 47, 63, 15),
(50, 48, 63, 30),
(51, 49, 63, 30),
(52, 50, 63, 30),
(53, 51, 63, 30),
(54, 52, 63, 30),
(55, 99, 63, 20),
(56, 100, 63, 20),
(58, 82, 55, 30),
(59, 83, 55, 30),
(60, 84, 55, 30),
(61, 85, 55, 30),
(62, 60, 6, 340),
(63, 61, 6, 240),
(64, 62, 6, 218),
(66, 63, 6, 240),
(67, 86, 64, 30),
(68, 87, 64, 30),
(70, 88, 64, 30),
(71, 89, 64, 30),
(72, 73, 28, 20),
(73, 74, 28, 20),
(74, 75, 28, 20),
(75, 76, 28, 20),
(76, 77, 28, 20),
(77, 97, 59, 20),
(78, 98, 59, 20),
(79, 37, 10, 0);

-- --------------------------------------------------------

--
-- Table structure for table `worpt`
--

CREATE TABLE `worpt` (
  `worptid` int(11) NOT NULL,
  `reference` text NOT NULL,
  `ProdId` int(11) NOT NULL,
  `reason` varchar(20) NOT NULL,
  `worptqty` text NOT NULL,
  `worptdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `worpt`
--

INSERT INTO `worpt` (`worptid`, `reference`, `ProdId`, `reason`, `worptqty`, `worptdate`) VALUES
(14, '984574923', 4, 'Expired', '5', '2020-07-11'),
(15, '388516415', 47, 'Expired', '5', '2020-07-21');

-- --------------------------------------------------------

--
-- Table structure for table `writeoff`
--

CREATE TABLE `writeoff` (
  `WOId` int(11) NOT NULL,
  `ProdId` int(11) NOT NULL,
  `reason` text NOT NULL,
  `WoQty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aaudit`
--
ALTER TABLE `aaudit`
  ADD PRIMARY KEY (`aauditid`),
  ADD KEY `ProdId` (`ProdId`),
  ADD KEY `DispId` (`DispId`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `audit`
--
ALTER TABLE `audit`
  ADD PRIMARY KEY (`AuditIW`),
  ADD KEY `ProdId` (`ProdId`);

--
-- Indexes for table `auditrpt`
--
ALTER TABLE `auditrpt`
  ADD PRIMARY KEY (`auditrptid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`categoryID`);

--
-- Indexes for table `clerk`
--
ALTER TABLE `clerk`
  ADD PRIMARY KEY (`ClerkId`);

--
-- Indexes for table `display`
--
ALTER TABLE `display`
  ADD PRIMARY KEY (`DispId`),
  ADD KEY `ProdId` (`ProdId`),
  ADD KEY `RackId` (`RackId`);

--
-- Indexes for table `invoice`
--
ALTER TABLE `invoice`
  ADD PRIMARY KEY (`invId`),
  ADD KEY `RegNo` (`RegNo`),
  ADD KEY `ProdId` (`ProdId`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`NotyId`);

--
-- Indexes for table `ord`
--
ALTER TABLE `ord`
  ADD PRIMARY KEY (`OrdId`),
  ADD KEY `ProdId` (`ProdId`),
  ADD KEY `RegNo` (`RegNo`);

--
-- Indexes for table `ordcart`
--
ALTER TABLE `ordcart`
  ADD PRIMARY KEY (`cartid`),
  ADD KEY `ProdId` (`ProdId`);

--
-- Indexes for table `ordrpt`
--
ALTER TABLE `ordrpt`
  ADD PRIMARY KEY (`ordrptid`),
  ADD KEY `OrdId` (`Ordno`),
  ADD KEY `ProdId` (`ProdId`),
  ADD KEY `RegNo` (`RegNo`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`PayId`),
  ADD KEY `OrdId` (`OrdId`),
  ADD KEY `invId` (`invId`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProdId`),
  ADD KEY `categoryID` (`categoryID`),
  ADD KEY `RegNo` (`RegNo`),
  ADD KEY `SubCategoryID` (`SubCategoryID`);

--
-- Indexes for table `rack`
--
ALTER TABLE `rack`
  ADD PRIMARY KEY (`RackId`),
  ADD KEY `categoryID` (`categoryID`),
  ADD KEY `SubCategoryID` (`SubCategoryID`);

--
-- Indexes for table `returnn`
--
ALTER TABLE `returnn`
  ADD PRIMARY KEY (`ReId`),
  ADD KEY `ProdId` (`ProdId`),
  ADD KEY `RegNo` (`RegNo`);

--
-- Indexes for table `returnrpt`
--
ALTER TABLE `returnrpt`
  ADD PRIMARY KEY (`rerpt`),
  ADD KEY `RegNo` (`RegNo`),
  ADD KEY `ProdId` (`ProdId`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`SubCategoryID`),
  ADD KEY `categoryID` (`categoryID`);

--
-- Indexes for table `supervisor`
--
ALTER TABLE `supervisor`
  ADD PRIMARY KEY (`SvId`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`RegNo`);

--
-- Indexes for table `transfer`
--
ALTER TABLE `transfer`
  ADD PRIMARY KEY (`transferid`),
  ADD KEY `ProdId` (`ProdId`);

--
-- Indexes for table `transhistory`
--
ALTER TABLE `transhistory`
  ADD PRIMARY KEY (`transferid`),
  ADD KEY `ProdId` (`ProdId`);

--
-- Indexes for table `warehouse`
--
ALTER TABLE `warehouse`
  ADD PRIMARY KEY (`warehouseId`),
  ADD KEY `ProdId` (`ProdId`),
  ADD KEY `RackId` (`RackId`);

--
-- Indexes for table `worpt`
--
ALTER TABLE `worpt`
  ADD PRIMARY KEY (`worptid`),
  ADD KEY `ProdId` (`ProdId`);

--
-- Indexes for table `writeoff`
--
ALTER TABLE `writeoff`
  ADD PRIMARY KEY (`WOId`),
  ADD KEY `ProdId` (`ProdId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aaudit`
--
ALTER TABLE `aaudit`
  MODIFY `aauditid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `audit`
--
ALTER TABLE `audit`
  MODIFY `AuditIW` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auditrpt`
--
ALTER TABLE `auditrpt`
  MODIFY `auditrptid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `categoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `display`
--
ALTER TABLE `display`
  MODIFY `DispId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;

--
-- AUTO_INCREMENT for table `invoice`
--
ALTER TABLE `invoice`
  MODIFY `invId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=85;

--
-- AUTO_INCREMENT for table `ord`
--
ALTER TABLE `ord`
  MODIFY `OrdId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=119;

--
-- AUTO_INCREMENT for table `ordcart`
--
ALTER TABLE `ordcart`
  MODIFY `cartid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ordrpt`
--
ALTER TABLE `ordrpt`
  MODIFY `ordrptid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ProdId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;

--
-- AUTO_INCREMENT for table `rack`
--
ALTER TABLE `rack`
  MODIFY `RackId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `returnn`
--
ALTER TABLE `returnn`
  MODIFY `ReId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `returnrpt`
--
ALTER TABLE `returnrpt`
  MODIFY `rerpt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `SubCategoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT for table `transfer`
--
ALTER TABLE `transfer`
  MODIFY `transferid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transhistory`
--
ALTER TABLE `transhistory`
  MODIFY `transferid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `warehouse`
--
ALTER TABLE `warehouse`
  MODIFY `warehouseId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `worpt`
--
ALTER TABLE `worpt`
  MODIFY `worptid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `writeoff`
--
ALTER TABLE `writeoff`
  MODIFY `WOId` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
