<?php
if(empty($_SESSION['username'])){
    session_start();
}
require $_SERVER['DOCUMENT_ROOT']."/psm/model/loginmodel.php";

class logincontroller{

	function validate(){
	$user = new loginmodel();
	$user->username = $_POST['username'];
        $user->password = $_POST['password'];
        $user->role = $_POST['role'];
        $stmt = $user->login();
        if($stmt > 0){
            $username = $_POST['username'];
            $_SESSION['username']=$username;
            $message = "Welcome!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../view/".$_POST['role']."';</script>";
        }
        else{
            $message = "PLEASE ENTER ID AND PASSWORD CORRECTLY";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../view/login.php';</script>";
		}
	}
        
        function user(){
        $user = new loginmodel();
        $stmt = $user->user();
        return $stmt;
        }
        
        function user2(){
        $user = new loginmodel();
        $stmt = $user->user2();
        return $stmt;
        }

        function notify(){
            return loginmodel::notify();
        }

}
?>