<?php
include 'header.php';
require_once '../../controller/clerk/reportController.php';

$vendor = new reportController();
$data = $vendor->retrievevendor();
?>

    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i>Smart Supermarket</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="icon_documents"></i>Invoice</li>
            </ol>
          </div>
        </div>
          
          
          <div class="row">
              <div class="col-lg-6">
                <section class="panel">
                  <header class="panel-heading">
                    <i class="fa fa-bookmark"></i>Vendor Invoice
                  </header>
                  <div class="panel-body">
                                         
                      <!--table report-->
                      <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th>No</th>
                    <th>Vendor</th>
                    <th>References</th>
                    <th>Date</th>
                    
                  </tr>
                </thead>               
                    <?php
                    $counter=1;
                    foreach ($data as $row){
                        echo "<tr>"
                        . "<td>".$counter."</td>"
                        . "<td>".$row['SuppCompany']."</td>"
                        . "<td>".$row['OrdInv']."</td>"
                        . "<td>".$row['OrdDate']."</td>";
                        echo "</tr>";
                        $counter++;
                    }
                       ?>
              </table>
                      
                  </div>
                    
                </section>
              </div>
          </div>

          
      </section>
    </section>                  
  
<?php
include 'footer.php';
?>