<?php
require_once '../../controller/supervisor/productController.php';

$product = new productController();
$product->delete($_GET['param']);

?>

