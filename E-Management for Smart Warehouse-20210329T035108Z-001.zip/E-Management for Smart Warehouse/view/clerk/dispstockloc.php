<?php
 include 'header.php';
 require_once '../../controller/clerk/prodcontroller.php';
 
 $product = new ProdController;
 $data = $product ->viewprods();

?>

    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-laptop"></i>Display Stock Rack</li>
            </ol>
          </div>
        </div><input class="btn btn-info" type="submit" onclick="window.location.href='stockloc.php'" value="Warehouse Stock Rack">
        <div class="row">
          <div class="control-label col-lg-10">
              <br>
              <div class="control-label col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Store Product Location
              </header>
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                      <th><i class=""></i>Rack No</th>
                      <th><i class=""></i>Category</th>
                      <th><i class=""></i>Sub - Category</th>
                    <th><i class=""></i>Product Code</th>
                    <th><i class=""></i>Product Name</th>
                    <th><i class=""></i>Product Price</th>
                    <th><i class=""></i>Quantity</th>
                  </tr>
                </thead>
                <?php
                    foreach ($data as $value) {
                        echo "<tr>"?>
                        <td><?= $value['rackno']?></td>
                        <td><?= $value['categoryName']?></td>
                        <td><?= $value['SubCategoryName']?></td>
                        <td><?= $value['ProdCode']?></td>
                        <td><?= $value['ProdName']?></td>
                        <td><?= $value['ProdPrice']?></td>
                        <td><?= $value['Dqty']?></td>
                    <?php
                     echo "</tr>";
                    }
                    ?>
              </table>              
            </section>
              </div>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>


<?php
 include 'footer.php';
?>
