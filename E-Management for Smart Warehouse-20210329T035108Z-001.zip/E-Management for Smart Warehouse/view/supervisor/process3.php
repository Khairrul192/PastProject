<?php
require_once '../../controller/supervisor/orderController.php';

$Sorder = new SorderController();
$data = $Sorder->getproduct($_POST['idsub']);

?>
<option disabled selected value>Product</option>
<?php
foreach($data as $row) {

		echo "<option value=".$row['ProdId'].">".$row['ProdName']."</option>";
}
?>