<?php
require 'header.php';
require_once '../../controller/supervisor/productController.php';
$product = new productController();
$data = $product->viewallprod();
?>
<body>

<div class="container">
  <div style="margin: 10%;">
      <form action="" method="POST">
      <div class="form-group">
        <label class="control-label col-sm-2" for="print_qty">Barcode Quantity</label>
        <div class="col-sm-10">          
          <select class="form-control" id="print_qty"  name="print_qty" onchange="form.submit()">
            <option disabled selected>Barcode Quantity</option>
            <?php
            for($x=1;$x<31;$x++){
              echo "<option value='".$x."'>".$x."</option>";
            }
            ?>
          </select>
          <p><p>
        </div>
      </div>
    </form>


  	<form class="form-horizontal" method="post" action="barcode.php" target="_blank">
      <?php
    if(isset($_POST['print_qty'])){
      for($xx=0;$xx<$_POST['print_qty'];$xx++){
        ?>
  	<div class="form-group">
      <label class="control-label col-sm-2" for="productname">Product Name:</label>
      <div class="col-sm-10">
        <select class="form-control" id="product"  name="product[]" >
          <?php
          $i=1;
          $xxx = "row".$i;
          foreach($data as $xxx){
            echo "<option value='".$xxx['ProdId']."'>".$xxx['ProdName']."</option>";
          }
          $i++;
          ?>
          </select>
      </div>
    </div>
  <?php }}
  else{
    ?>
    <div class="form-group">
      <label class="control-label col-sm-2" for="productname">Product Name:</label>
      <div class="col-sm-10">
        <select class="form-control" id="product"  name="product[]">
          <?php
          foreach($data as $row){
            echo "<option value='".$row['ProdId']."'>".$row['ProdName']."</option>";
          }
          ?>
          </select>
      </div>
    </div>
  <?php 
  } 
  ?>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>
    </div>
  </form>
  </div>
</div>
</body>
</html>
