<?php
require_once '../../model/clerk/prodModel.php';

class ProdController{
    
    function viewcategory(){
        $product = new ProdModel();
        return $product->viewcategory();
    }
    function Subcategory($categoryID){//cascade addproductcascade.php
        $product = new ProdModel();
        return $product->subcategory($categoryID);
    }
    
    function rackNo($subcategoryID){//cascade addproductcascade.php
        $product = new ProdModel();
        return $product->rackno($subcategoryID);
    }
    
    function viewsupplier(){
        $product = new ProdModel();
        return $product->viewsupp();
    }
    
    function addprod(){
        $product = new ProdModel();
        $product ->category = $_POST['category'];
        $product ->subcategory = $_POST['subcategory'];
        $product ->prodcode = $_POST['prodCode'];
        $product ->prodname = $_POST['prodName'];
        $product ->prodprice = $_POST['prodPrice'];
        $product ->supplier = $_POST['supplier'];
        
        if($product->insertprod()>0){
            $message = "Successfully Add!";
    		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/addprod.php;</script>";
        }
    }
    
    function viewallproducts(){
        $product = new ProdModel();
        return $product->viewallproducts();
    }
    
    function viewprod($viewprod){
        $product = new ProdModel();
        $product->prodid = $viewprod;
        return $product->viewprod();
    }
    
    function editprod(){
        $product = new ProdModel();
        $product ->prodid = $_POST['ProdId'];
        $product ->prodcode = $_POST['prodCode'];
        $product ->prodname = $_POST['prodName'];
        $product ->prodprice = $_POST['prodPrice'];
        $product ->cat = $_POST['cat'];
        $product ->rackno = $_POST['rackno'];
        $product ->suppid = $_POST['regno'];
        
        if($product->modifyprod()){
            $message = "Successfully Edit!";
    		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/supplierprod.php?param=".$_POST['regno']."';</script>";
        }
    }
    
    function delete(){
        $product = new ProdModel();
        $product ->product = $_POST['delprod'];
        if($product->deleteproduct()){
            $message = "Success Delete!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/clerk/viewprod.php';</script>";
        }
    }
    
    function viewproduct() {
        $product = new ProdModel();
        return $product -> viewallprod();
        
    }
    
    function viewprods() {
        $product = new ProdModel();
        return $product -> vallprod();
        
    }
    
//    function AOD() {
//        $product = new ProdModel();
//        $product ->prodname = $_POST['prodname'];
//        $product ->rackno = $_POST['rackno'];
//        
//        if($product->aod()>0){
//            $message = "Successfully Add!";
//    		echo "<script type='text/javascript'>alert('$message');
//		window.location = '../../view/clerk/addtodisplay.php';</script>";
//        }
//    }
    
//    function viewaod(){
//        $product = new ProdModel();
//        return $product -> viewAOD();
//    }
}