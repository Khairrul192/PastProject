<?php
require_once '../../controller/clerk/categoryController.php';

$category = new categoryController();
$data = $category->getrack($_POST['idsubs'],$_POST['subs']);

?>
<option disabled selected value>Rack</option>
<?php
foreach($data as $row) {

		echo "<option value=".$row['RackId'].">".$row['rackno']."</option>";
}
?>