<?php
require('../fpdf/fpdf.php');
require_once '../../controller/supervisor/productController.php';

$product = new productController();
$view = $product->viewWOlist($_GET['viewwriteoff']);
 
$pdf=new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial','B',16);
foreach($view as $row){                       
$pdf->Cell(40,10,$row['ProdCode'].",".$row['ProdName'].",".$row['worptqty'].", RM".sprintf("%.2f",(float)$row['ProdPrice']*1.1).", RM".$row['ProdPrice'].", ".$row['reason'].", ".(int)$row['worptqty']*(float)$row['ProdPrice']);
}
$pdf->Output();
?>