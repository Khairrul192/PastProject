<?php
session_start();
require_once '../../model/admin/userModel.php';

class userController{
    public $id,$pass,$name,$email,$phono,$add,$role;
    
    function insert(){
        $user = new userModel();
        $user->id = $_POST['Id'];
        $user->pass = $_POST['password'];
        $user->name = $_POST['name'];
        $user->email = $_POST['email'];
        $user->phono = $_POST['Pno'];
        $user->add = $_POST['address'];
        $user->role = $_POST['role'];
        $stmt = $user->register();
        if($stmt > 0){
            $message = "Register Successful!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../admin/User.php';</script>";
        }
        else{
            $message = "Register fail!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../admin/register.php';</script>";
        }
       
    }
    
    function viewC(){
        $user = new userModel();
        return $user->viewallclerk();
    }
    
    function viewS(){
        $user = new userModel();
        return $user->viewallsupervisor();
    }
    
    function viewclerk($viewcl){
        $user = new userModel();
        $user->id = $viewcl;
        return $user->viewclerk();
    }
    
    function viewsv($viewsv){
        $user = new userModel();
        $user->id = $viewsv;
        return $user->viewsupervisor();
    }
    
    function delsv(){
        $product = new userModel();
        $product ->SvId = $_POST['SvId'];
        if($product->svdel()){
            $message = "Success Delete!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/admin/User.php';</script>";
        }
    }
    
    function delcl(){
        $product = new userModel();
        $product ->ClerkId = $_POST['ClerkId'];
        if($product->cldel()){
            $message = "Success Delete!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/admin/User.php';</script>";
        }
    }
}
?>