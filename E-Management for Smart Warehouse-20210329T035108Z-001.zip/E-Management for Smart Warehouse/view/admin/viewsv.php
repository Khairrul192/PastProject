<?php
include 'header.php';
require_once '../../controller/admin/userController.php';

$viewsv = $_GET['viewsupervisor'];

$user = new userController();
$data = $user->viewsv($viewsv);

?>

<html>
    <body>
    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                <li><i class="fa fa-laptop"></i><a href="user.php">Staff</a></li>
              <li><i class="fa fa-laptop"></i>Staff Information</li>
            </ol>
          </div>
        </div>
    
    <!--supplier form start-->
                   <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Staff Detail
              </header>
                <?php
            foreach($data as $detail){
            ?> 
              <div class="panel-body">
                <div class="form">
                  <form class="form-validate form-horizontal" method="POST" action="">
                    <div class="form-group ">
                      <label class="control-label col-lg-2"> Name</label>
                      <div class="col-lg-10">
                        <td><?=$detail['SvName']?></td>
                      </div>
                    </div>
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Phone Number</label>
                      <div class="col-lg-10">
                        <td><?=$detail['SvPNo']?></td>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Email</label>
                      <div class="col-lg-10">
                          <td><?=$detail['SvEmail']?></td>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2"> Address</label>
                      <div class="col-lg-10">
                        <td><?=$detail['SvAdd']?></td>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                        <input type="button" class="btn btn-default" onclick="location.href='User.php'" value="BACK">
                        
                      </div>
                    </div>
                </div>
<?php } ?>
              </div>
            </section>
          </div>
        </div>
           <!--supplier form end-->
            </section>

    <!--main content end-->
  </section>
</body>
</html>
<?php
include 'footer.php';
?>