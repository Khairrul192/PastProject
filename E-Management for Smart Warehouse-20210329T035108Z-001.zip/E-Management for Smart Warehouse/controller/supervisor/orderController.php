<?php
require_once '../../model/supervisor/orderModel.php';

class SorderController{
    
    function addorder(){
        $Sorder = new SorderModel();
        $Sorder -> prodid = $_POST['product'];
        $Sorder->createorder();

        //$message = "Successfully Add!";
        echo "<script type='text/javascript'>;
        window.location = '../../view/supervisor/orderprod.php';</script>";
    }
    
    function vieworderlist($vieworder){
        $Sorder = new SorderModel();
        $Sorder->ordref = $vieworder;
        return $Sorder->viewlistorder();
    }
    
    function vieworder() {
        $Sorder = new SorderModel();
        return $Sorder->viewallorder();        
    }
    
    function vieworder1($RegNo) {
        $Sorder = new SorderModel();
        $Sorder->regno = $RegNo;
        return $Sorder->viewallorder1();        
    }
    
    function invoicelist() {
        $Sorder = new SorderModel();
        return $Sorder->viewinvoicelist();        
    }
    
    function viewinvoice($invoice){
        $Sorder = new SorderModel();
        $Sorder->refno = $invoice;
        return $Sorder->invoice();
    }
    
    function category(){//cascade orderprod.php
        $Sorder = new SorderModel();
        return $Sorder->getCategory();
    }
    function Subcategory($categoryID){//cascade process2.php
        $Sorder = new SorderModel();
        return $Sorder->getSubCategory($categoryID);
    }
    
    function getproduct($subcategoryID){//cascade process3.php
        $Sorder = new SorderModel();
        return $Sorder->getproduct($subcategoryID);
    }
    
    function viewordersupplier(){
        $Sorder = new SorderModel();
        return $Sorder->viewordersupplier();
    }
    
    function setorder(){//orderprod.php action to order item
        $Sorder = new SorderModel();
        $number = sizeof($_POST['order']);
        for($i=0;$i<$number;$i++){
        $Sorder ->prodid = $_POST['prodid'][$i];
        $Sorder ->qty = $_POST['order'][$i];
        $Sorder ->suppid = $_POST['suppid'][$i];
        $Sorder->setorder();}
            $message = "Successfully Add!";
    		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/supervisor/setorder.php';</script>";
    }
    
    function createorder(){//setorder.php action to confirm order
        $Sorder = new SorderModel();
        for($i=0;$i<sizeof($_POST['order']);$i++){
            $Sorder ->suppid = $_POST['suppid'][$i];
            $Sorder ->ordref = $_POST['ordref'][$i];
            $iii = 'prodid'.$i;
            $iv = 'qty'.$i;
            for($ii=0;$ii<sizeof($_POST[$iii]);$ii++){
                $Sorder ->prodid = $_POST[$iii][$ii];
                $Sorder ->qty = $_POST[$iv][$ii];
                $Sorder ->date = date('Y/m/d');
                $Sorder->createsorder();
                $Sorder->deleteorder1();
            }
        }
        $message = "Order Released!";
        echo "<script type='text/javascript'>alert('$message');window.location = '../../view/supervisor/setorder.php';</script>";
    }
    
    function viewsupporder(){
        $Sorder = new SorderModel();
        return $Sorder->viewsupporder();
    }
    
    function deleteorder(){
        $category = new SorderModel();
        $category->delete = $_POST['delet'];
        if($category->deleteorder()){
            $message = "Success Delete!";
		echo "<script type='text/javascript'>alert('$message');
		window.location = '../../view/supervisor/orderprod.php';</script>";
        }
    }

}
?>