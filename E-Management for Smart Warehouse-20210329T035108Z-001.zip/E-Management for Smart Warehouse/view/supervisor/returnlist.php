<?php
include 'header.php';
require_once '../../controller/supervisor/productController.php';

$product = new productController();
$data = $product -> viewsupp();

?>

<section id="main-content">
  <section class="wrapper">

    <div class="row">
      <div class="col-lg-12">
        <ol class="breadcrumb">
            <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
          <li><i class="fa fa-truck"></i>Vendor</li>
        </ol>
      </div>
    </div>
      
      
         <div class="row">
      <div class="col-sm-6">
        <section class="panel">
          <header class="panel-heading">
            Supplier
          </header>

          <table class="table">
            <thead>
              <tr>
                <th><i class="icon_profile"></i>Vendor</th>
                <th><i class="icon_cogs"></i> Action</th>
              </tr>
            </thead>
            <tr>
            <?php
            foreach ($data as $value) {
                echo "<tr>"
                    . "<td>".$value['SuppCompany']."</td>";
            ?>
            <td>
                <form action="" method="POST">
                    <input type="button" class="btn btn-info" value="Create Return" onclick="location.href='return.php?return=<?=$value['RegNo']?>'">&nbsp;
            </td>
            </tr>
            <?php
                 echo "</tr>";
                }
                ?>
          </table>
        </section>
          <input type="button" class="btn btn-success" onclick="location.href='returnpast.php'" value="History">
          </form>
      </div>
    </div>
  </section>
<!--main content end-->
</section>   

<?php
include 'footer.php';
?>