<?php
require $_SERVER['DOCUMENT_ROOT']."/psm/library/database.php";

class loginmodel{
  
    public $username,$password,$role;
    
    function login(){
        if($this->role == "clerk"){
        $query = "select * from clerk where ClerkId=:username and ClerkPwd=:password";
        $param = [':username' => $this->username, ':password' => $this->password];
        $result = DB::run($query, $param);
        $cek = $result->rowCount();
        return $cek;
        }
        if($this->role == "supervisor"){
        $query = "select * from supervisor where SvId=:username and SvPwd=:password";
        $param = [':username' => $this->username, ':password' => $this->password];
        $result = DB::run($query, $param);
        $cek = $result->rowCount();
        return $cek;
        }
        if($this->role == "admin"){
        $query = "select * from admin where adminUsername=:username and adminPass=:password";
        $param = [':username' => $this->username, ':password' => $this->password];
        $result = DB::run($query, $param);
        $cek = $result->rowCount();
        return $cek;
        }
    }
    
    function user(){
        $sql = "select * from supervisor where SvId='".$_SESSION['username']."'";
        $stmt = DB::run($sql);
        return $stmt;
    }
    
    function user2(){
        $sql = "select * from clerk where ClerkId='".$_SESSION['username']."'";
        $stmt = DB::run($sql);
        return $stmt;
    }

    function notify(){
        $sql = "select * from warehouse,product where warehouse.Wqty<10 and warehouse.ProdId=product.ProdId";
        return DB::run($sql);
    }
}