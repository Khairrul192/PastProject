<?php
require_once 'header.php';
require_once '../../controller/clerk/categoryController.php';

$category = new categoryController();
$cat = $category->category();

if(isset($_POST['addrack'])){// add rackNo
   $category->addrack();
}

$data = $category->viewrack(); // view warehouse rack detail
$dataa = $category->viewrack2(); // view display rack detail

if(isset($_POST['delete'])){
    $category->delrack();
}
?>

    <!--main content start-->
<section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-laptop"></i>Manage Rack</li>
            </ol>
          </div>
        </div>
        <div class="row">
            <div class="col-lg-7">
                <br>
              <form class="form" method="POST" action="">
                    <div class="form-group ">
                      <label class="control-label col-lg-3">Category</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="category" name="category">
                                <option disabled selected value>Select Category</option>
                                <?php
                                foreach($cat as $view){
                                    echo "<option value='".$view['categoryID']."'>".$view['categoryName']."</option>";
                                }
                                ?>
                            </select>
                      </div><br><br>
                      <label class="control-label col-lg-3">Sub Category</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="subcategory" name="subcategory">
                                <option disabled selected value>Select Sub Category</option>
                            </select>
                      </div><br><br>
                      
                      <label class="control-label col-lg-3">Location</label>
                      <div class="col-lg-4">
                          <select class="form-control" id="placement" name="placement">
                                <option disabled selected value>Select Location</option>
                                <option value="Warehouse">Warehouse</option>
                                <option value="Display">Display</option>
                            </select>
                      </div><br><br>
                      
                      <label class="control-label col-lg-3">Rack No</label>
                      <div class="col-lg-4">
                          <input type="text" name="rack" class="form-control" required/>
                      </div>    
                      <input class="btn btn-info" type="submit" name="addrack" value="Add Rack">
                    </div>
                </form>
            </div>
          </div>
        <div class="row">
           <div class="col-lg-6"><!--warehouse rack-->
              <br>
            <section class="panel">
              <header class="panel-heading">
                Warehouse Rack
              </header>
                
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th><i class=""></i>Rack No</th> 
                    <th><i class="icon_cart_alt"></i> Category</th>
                    <th><i class="icon_cart"></i> Sub - Category</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>
                <?php
                foreach($data as $row){
                       echo "<tr>"
                        . "<td>".$row['rackno']."</td>"
                        . "<td>".$row['categoryName']."</td>"
                        . "<td>".$row['SubCategoryName']."</td>"
                       ?>
                <td><form action="" method="POST">
                            <input type="hidden" name="delrack" value="<?=$row['RackId']?>"> <input type="submit" class="btn btn-danger" name="delete" value="Delete Rack">&nbsp;
                        </form></td>
                      <?php 
                      echo "</tr>";
                }
                    ?>
              </table>
            </section>
          </div>
            <div class="col-lg-6"><!--Display rack-->
              <br>
            <section class="panel">
              <header class="panel-heading">
                Display Rack
              </header>
                
              <table class="table table-striped table-advance table-hover">
                <thead>
                  <tr>
                    <th><i class=""></i>Rack No</th> 
                    <th><i class="icon_cart_alt"></i> Category</th>
                    <th><i class="icon_cart"></i> Sub - Category</th>
                    <th><i class="icon_cogs"></i> Action</th>
                  </tr>
                </thead>
                <?php
                foreach($dataa as $row){
                       echo "<tr>"
                        . "<td>".$row['rackno']."</td>"
                        . "<td>".$row['categoryName']."</td>"
                        . "<td>".$row['SubCategoryName']."</td>"
                       ?>
                <td><form action="" method="POST">
                            <input type="hidden" name="delrack" value="<?=$row['RackId']?>"> <input type="submit" class="btn btn-danger" name="delete" value="Delete Rack">&nbsp;
                        </form></td>
                      <?php 
                      echo "</tr>";
                }
                    ?>
              </table>
              
            </section>
          </div>
        </div>
          
      </section>
    <!--main content end-->
  </section>
<script language="JavaScript" type="text/javascript" src="jquery-1.11.1.min.js"></script>
        <script>
function select_cir(id) {
$.ajax({
                type : "POST",
                data : {id:id},
                url : "process.php",
                success : function (res2) {
                        //alert(res2);
                        $('#subcategory').append(res2);
                },
                //error:function (res2){
                        //alert("error");}
        });
}
$(document).ready(function(e) {
$("#category").on("change",function() {
var id = document.getElementById("category").value;

document.getElementById("subcategory").options.length=0;
select_cir(id);
});
});
</script>
<?php
include 'footer.php';
?>
