<?php
require_once 'header.php';
require_once '../../controller/clerk/supplierController.php';

$editSupp = $_GET['editsupplier'];

$supplier = new supplierController();
$data = $supplier->viewsupp($editSupp);

if(isset($_POST['update'])){
    $supplier->editsupplier();
}
?>

<html>
<body>
    
    <section id="main-content">
      <section class="wrapper">
        
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa-laptop"></i> SMART SUPERMARKET</h3>
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
                <li><i class="fa fa-laptop"></i><a href="supplier.php">Supplier</a></li>
              <li><i class="fa fa-laptop"></i>Edit Supplier</li>
            </ol>
          </div>
        </div>
    
    <!--supplier form start-->
                   <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Supplier Form
              </header>
              <div class="panel-body">
                <div class="form">
                  <form class="form-validate form-horizontal" method="POST" action="">
                    <?php
                        foreach($data as $detail){
                        ?>
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Supplier Company</label>
                      <div class="col-lg-10">
                        <input type="text" class="form-control" name="Suppcomp" value="<?=$detail['SuppCompany']?>">
                      </div>
                    </div>
                      <div class="form-group ">
                      <label class="control-label col-lg-2">Registration Number</label>
                      <div class="col-lg-10">
                        <input type="text" class="form-control" name="SRegNo" value="<?=$detail['RegNo']?>" readonly>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Email</label>
                      <div class="col-lg-10">
                          <input type="text" class="form-control" name="email" value="<?=$detail['SuppEmail']?>">
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Contact Number</label>
                      <div class="col-lg-10">
                        <input type="text" class="form-control" name="CNo" value="<?=$detail['SuppCNo']?>" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required></td>
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Account</label>
                      <div class="col-lg-10">
                        <input type="text" class="form-control" name="AccNo" value="<?=$detail['SuppAccno']?>">
                      </div>
                    </div>
                    <div class="form-group ">
                      <label class="control-label col-lg-2">Detail</label>
                      <div class="col-lg-10">
                        <input type="text" class="form-control" name="SuppDetail" value="<?=$detail['SuppDetail']?>">
                      </div>
                      </div>
                    <div class="form-group">
                      <div class="col-lg-offset-2 col-lg-10">
                          <input class="btn btn-success" type="submit" name="update" value="Update">
                          <input type="button" class="btn btn-default" onclick="location.href='viewsupp.php?viewsupplier=<?=$detail['RegNo']?>'" value="BACK">
                      </div>
                    </div>
                  </form>
                </div>
<?php } ?>
              </div>
            </section>
          </div>
        </div>
           <!--supplier form end-->
            </section>
          </div>
        </div>
    <!--main content end-->
  </section>
</body>

</html>