<?php
require_once '../../controller/clerk/prodController.php';

$product = new ProdController();
$data = $product->Subcategory($_POST['id']);

?>
<option disabled selected value>Sub Category</option>
<?php
foreach($data as $sub) {

		echo "<option value=".$sub['SubCategoryID'].">".$sub['SubCategoryName']."</option>";
}
?>

