<?php
require_once 'header.php';
require_once '../../controller/supervisor/productController.php';

$product = new productController();

if(isset($_POST['add'])){
    $data = $product->rcvitem();
}

if(isset($_POST['receive'])){
    $product->addtowarehouse();
}

?>

    <!--main content start-->
<section id="main-content">
      <section class="wrapper">        
        <div class="row">
          <div class="col-lg-12">
            <ol class="breadcrumb">
                <li><i class="fa fa-home"></i><a href="index.php">Home</a></li>
              <li><i class="fa fa-laptop"></i>Receiving</li>
            </ol>
          </div>
        </div>
        <div class="row">
          <div class="col-lg-10">
              <form class="form-validate form-horizontal" method="POST" action="">
                    <div class="form-group ">
                        <table>
                            
                            <tr><td>
                                    <label class="control-label col-lg-4">Order No </label>
                                    <div class="col-lg-8">
                                    <input class="form-control" name="OrdRef" type="text" required />
                                </td>
                      <td><input class="btn btn-info" type="submit" name="add" value="Submit"></td>
                      </div>
                        </tr>
                        </table>
                    </div>
                </form>
              <br>
            <form class="form-horizontal" method="POST" action="">
                <table>
                      <tr><td>
                      <label class="control-label col-lg-3">Invoice</label>
                      <div class="col-lg-8">
                          <input class="form-control" name="invoice" type="text" required /></td>
                      <td>
                      <label class="control-label col-lg-4">Store Receipt</label>
                      <div class="col-lg-8">
                          <input class="form-control" name="receipt" type="text" value="<?=(mt_rand(1,9999))?>" readonly/>
                      </div>
                      </tr>
                </table>
                <br>
            <section class="panel">
              <header class="panel-heading">
                List of Item
              </header>
                
              <table class="table table-striped table-advance table-hover">
                <thead>
                    <th><i class=""></i>No</th> 
                    <th><i class=""></i>Code</th> 
                    <th><i class=""></i>Name</th>
                    <th><i class=""></i>Order Quantity</th>
                    <th><i class=""></i>Receive Quantity</th>
                </thead>
                <?php
                if(!empty($data)){
                    $counter=1;
                    foreach($data as $row){ 
                        echo "<tr>"?>
                        <td><?=$counter?></td>
                        <td><?=$row['ProdCode']?>
                        <input class="form-control" type="hidden" name="prodid[]" value="<?php echo $row['ProdId']?>">
                        <input class="form-control" type="hidden" name="regno" value="<?php echo $row['RegNo']?>">
                        </td>                        
                        <td><?=$row['ProdName']?></td>
                        <td><?= $row['qty']?>
                            <input class="form-control" type="hidden" name="ordqty[]" value="<?php echo $row['qty']?>">
                        </td>
                        <td>
                            <input class="form-control" name="rcvqty[]" value="<?php echo $row['qty']?>">
                        </td>
                  <?php
                     echo "</tr>";
                    $counter++;}
                    }
                    ?>                
              </table>
            </section>
                <label class="control-label col-lg-1">Remarks</label>
                      <div class="col-lg-2">
                          <select class="form-control" name="remarks" id="remarks">
                            <option disabled selected value>Remarks</option>
                            <option value="Correct Order">Correct Order</option>
                            <option value="Over Quantity">Over Quantity</option>
                            <option value="Less Quantity">Less Quantity</option>
                            <option value="Miss Product">Miss Product</option>
                            <option value="Unordered Product">Unordered Product</option>
                          </select>
                      </div>
                <br><br>
                  <input class="btn btn-primary" type="submit" name="receive" value="Receive">
              </form>
          </div>
        </div>
      </section>
    <!--main content end-->
  </section>

<?php
include 'footer.php';
?>
